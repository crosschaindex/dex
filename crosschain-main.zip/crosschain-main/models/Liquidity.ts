import { Schema, model, models, Document, Types } from "mongoose";

export interface LiquidityDocument extends Document {
    _id: string;
    createdAt: Date;
    user: string;
    pool: Types.ObjectId
    deposit: number
    reward: number

}

const LiquiditySchema = new Schema<LiquidityDocument>(
    {
        user: { type: String, lowercase: true, trim: true },
        pool: { type: Schema.Types.ObjectId, ref: 'Pool' },
        deposit: Number,
        reward: Number,
    },
    {
        timestamps: true,
    }
);

export default models.Liquidity || model<LiquidityDocument>('Liquidity', LiquiditySchema)


//export const User = model<UserDocument>("User", userSchema);
