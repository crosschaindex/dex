import { Schema, model, models,Document } from "mongoose";

export interface UserDocument extends Document {
  _id: string;
  createdAt: Date;
  email: string;
  avatar: string;
  username: string;
  nonce: number;
  publicAddress: string;
  bio: string;
  role: 'user'| 'creator',
  referral: string
}

const UserSchema = new Schema<UserDocument>(
  {
    email: { type: String, lowercase: true, trim: true },
    username: { type: String, lowercase: true, trim: true },
    avatar: String,
    nonce: Number,
    publicAddress: { type: String, lowercase: true, unique: true, trim: true },
    bio: String,
    role: {type: String, default: 'user'},
    referral: String
  },
  {
    timestamps: true,
  }
);

export default models.User || model<UserDocument>('User', UserSchema)


//export const User = model<UserDocument>("User", userSchema);
