import { Schema, model, models, Document } from "mongoose";

export interface PoolDocument extends Document {
    _id: string;
    createdAt: Date;
    primary: string;
    secondary: string;
    apy: number;
    total: number;
    pool_reward: number;
    emission_rate: number;

}

const PoolSchema = new Schema<PoolDocument>(
    {
        primary: { type: String, lowercase: true, trim: true },
        secondary: { type: String, lowercase: true, trim: true },
        apy: Number,
        total: Number,
        pool_reward: Number,
        emission_rate: Number,

    },
    {
        timestamps: true,
    }
);

export default models.Pool || model<PoolDocument>('Pool', PoolSchema)


//export const User = model<UserDocument>("User", userSchema);
