import { Schema, model, models,Document } from "mongoose";

export interface TransactionDocument extends Document {
  _id: string;
  createdAt: Date;
  hash:string;
  amount: string
  from:string
}

const TransactionSchema = new Schema<TransactionDocument>(
  {
    hash: { type: String, lowercase: true, trim: true },
    amount: String,
    from:String
  },
  {
    timestamps: true,
  }
);

export default models.Transaction || model<TransactionDocument>('Transaction', TransactionSchema)


//export const User = model<UserDocument>("User", userSchema);
