import React, { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../app/hooks";
import { ConnectWalletModal } from "../components/Modal";
import { USER_TOKEN } from "../constants";
// import { useAppDispatch, useAppSelector } from "../app/hooks";
import { authenticate, logOut } from "../store/user";
import { connectWallet } from "../web3";
// import { connectWallet } from "../web3";


export const UserProvider:React.FC<{children: React.ReactNode}> = ({children})=>{

    const dispatch = useAppDispatch();

    const user = useAppSelector((state) => state.user);
  
    useEffect(() => {
      (async () => {
        try{
          await connectWallet('metamask');
        }catch(err){
          console.log(err)
        }

       

        dispatch(authenticate());
      })().catch((err) => {
      //  alert(err.message);
      
        dispatch(logOut());
      });
    }, []);
  
    useEffect(() => {
      // if (user.status === "authenticated") {
      //   (async () => {
      //     try{
      //       await connectWallet();
      //     }catch(err:any){
      //       dispatch(logOut());
      //     }
      //   })();
      // }
  
      if (user.status === "failed") {
        dispatch(logOut());
      }
    }, [user]);
    return (
        <div>
            {children}
            <ConnectWalletModal/>
        </div>
    )
}




