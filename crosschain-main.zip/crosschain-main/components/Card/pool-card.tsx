import Link from "next/link"

export const PoolCard:React.FC<{pool:any}> = ({pool})=>{
    return (
        <div className="pool-divcontent">
        <span className="pooldiv-bg"></span>
        <span className="viperoverlay-bg"></span>
        <div className="pool-header">
          <div className="relative flex flex-row">
            <img
              src={`/assets/icons/tokens/${pool.primary}.svg`}
              className="pool-img"
            />
            <img
              className="pool-img-1"
              alt="CRC logo"
              src={`/assets/icons/tokens/${pool.secondary}.svg`}
            />
          </div>
          <div className="ml-2 font-semibold text-2xl min-w-0 m-0 text-white">
            {(pool.primary).toUpperCase()}-{(pool.secondary).toUpperCase()}
          </div>
          <Link href={`/deposit?id=${pool._id}`}>
            <a className="cursor-pointer font-medium text-blue w-full">
              <button className="deposit-btn">Deposit</button>
            </a>
          </Link>
        </div>
        <div className="flex justify-between flex-col gap-3 mx-4 mb-4">
          <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
            <div className="m-0 min-w-0 font-medium text-white">
              APY*
            </div>
            <div className="m-0 min-w-0 font-medium text-white">
              <b>{pool.apy}%</b>
            </div>
          </div>
          <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
            <div className="m-0 min-w-0 font-medium text-white">
              Total deposited
            </div>
            <div className="m-0 min-w-0 font-medium text-white">
              <b>${(pool.total).toLocaleString()}</b>
            </div>
          </div>
          <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
            <div className="m-0 min-w-0 font-medium text-white">
              Pool reward allocation
            </div>
            <div className="m-0 min-w-0 font-medium text-white">
            {pool.pool_reward}%
            </div>
          </div>
          <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
            <div className="m-0 min-w-0 font-medium text-white">
              Emission rate
            </div>
            <div className="m-0 min-w-0 font-medium text-white">
            {pool.emission_rate} CRC / block
            </div>
          </div>
        </div>
      </div>
    )
}