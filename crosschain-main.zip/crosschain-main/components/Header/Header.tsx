import Link from "next/link";
import { useRouter } from "next/router";
import { useState } from "react";
import { LogoutUser } from "../../app/auth";
import { useAppDispatch, useAppSelector } from "../../app/hooks";
import { setConnectModal } from "../../store/modal";
import { logOut } from "../../store/user";
import { minifyAddress } from "../../utils";

export const Header: React.FC = () => {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const user = useAppSelector((state) => state.user);

  const [stalkingSubHeader, setStalkingSubHeader] = useState(false);
  const [optionSubHeader, setOptionSubHeader] = useState(false);

  const handleConnect = (e: React.MouseEvent<HTMLElement>) => {
    e.preventDefault();
    dispatch(setConnectModal(true));
  };

  const handleLogout = async () => {
    try {
      await LogoutUser();
      dispatch(logOut());
      router.push("/");
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className="flex w-full justify-between flow-nowrap">
      <div className="sub-header">
        <div className="box-border m-0 p-0 flex min-w-0 items-center justify-start sub-header-top">
          <Link href="/">
            <a className="flex items-center pointer-events-auto mr-3">
              <div>
                <img
                  width="60px"
                  src="/assets/img/logo-1.png"
                  alt="logo"
                  className="rounded"
                />
              </div>
            </a>
          </Link>
          <div className="box-border m-0 min-w-0 w-full flex p-0 items-center justify-start nav">
            <Link href="/">
              <a aria-current="page" className="active" id="swap-nav-link">
                Swap
              </a>
            </Link>
            <Link href="/pool">
              <a id="pool-nav-link">Pool</a>
            </Link>
            <div className="flex justify-center items-center relative border-none text-left">
              <button
                onClick={() => setStalkingSubHeader(!stalkingSubHeader)}
                // onBlur={() => setStalkingSubHeader(false)}
                className="stake-btn"
              >
                <span role="img" aria-label="wizard-icon" className="mr-1">
                  ⚡
                </span>
                Staking
              </button>
              <span
                className={
                  stalkingSubHeader ? "stake-content" : "stake-content d-hide"
                }
              >
                <Link href="/pools">
                  <a id="stake-nav-link">Pools</a>
                </Link>
                <Link href="/CRCpit">
                  <a id="stake-nav-link">CRCPit</a>
                </Link>
                <Link href="/CRCnest">
                  <a id="stake-nav-link">CRCNest</a>
                </Link>
                <Link href="/community">
                  <a id="stake-nav-link">Community</a>
                </Link>
                <Link href="/bridge">
                  <a id="stake-nav-link">Bridge</a>
                </Link>
                <Link href="/unlock">
                  <a id="stake-nav-link">Unlock</a>
                </Link>
              </span>
            </div>
            <Link href="/chartsoverview">
              <a
                target="_blank"
                className="charts-btn"
                rel="noopener noreferrer"
                id="#"
              >
                Charts <span className="text-xs">↗</span>
              </a>
            </Link>
          </div>
        </div>
        <div className="flex flex-row items-center justify-self-end sub-header-bottom">
          <div className="flex items-center viper">
            <span className="d-hidden"></span>
            <span className="ml-2 w-fit relative cursor-pointer">
              <div className="viper-btn">CRC</div>
              <span></span>
            </span>
            <div className="ml-2 flex flex-row items-center rounded-xl whitespace-nowrap w-full cursor-pointer bg-white">
              {user.status === "authenticated" ? (
                <button
                  id="connect-wallet"
                  className="wallet-btn"
                  onClick={handleLogout}
                >
                  <p>{minifyAddress(user.user.publicAddress)}</p>
                </button>
              ) : (
                <button
                  onClick={handleConnect}
                  id="connect-wallet"
                  className="wallet-btn"
                >
                  <p>Connect a Wallet</p>
                </button>
              )}
            </div>
          </div>
          <div className="flex items-center">
            <button className="mode-btn">
              <img src="/assets/icons/mode-icon.svg" className="max-w-none" />
            </button>
            <div className="option-btn">
              <button onClick={() => setOptionSubHeader(!optionSubHeader)}>
                <img
                  src="/assets/icons/option-icon.svg"
                  className="max-w-none"
                />
              </button>
              <span
                className={
                  optionSubHeader ? "option-content" : "option-content d-hide"
                }
              >
                <Link href="/chartsoverview">
                  <a
                    target="_blank"
                    rel="noopener noreferrer"
                    id="link"
                    className="flex items-center font-medium lightgray p-2 cursor-pointer"
                  >
                    <img
                      src="/assets/icons/chart.svg"
                      className="max-w-none mr-3"
                    />
                    Charts
                  </a>
                </Link>
                <Link href="https://twitter.com/hashandblocks">
                  <a
                    target="_blank"
                    rel="noopener noreferrer"
                    id="link"
                    className="flex items-center font-medium lightgray p-2 cursor-pointer"
                  >
                    <img
                      src="/assets/icons/twitter.svg"
                      className="max-w-none mr-3"
                    />
                    Twitter
                  </a>
                </Link>
                <Link href="https://discord.gg/HucAXAD94t">
                  <a
                    target="_blank"
                    rel="noopener noreferrer"
                    href=""
                    id="link"
                    className="flex items-center font-medium lightgray p-2 cursor-pointer"
                  >
                    <img
                      src="/assets/icons/discord.svg"
                      className="max-w-none mr-3"
                    />
                    Discord
                  </a>
                </Link>
                {/* <Link href="https://coingecko.com">
                  <a
                    target="_blank"
                    rel="noopener noreferrer"
                    href=""
                    id="link"
                    className="flex items-center font-medium lightgray p-2 cursor-pointer"
                  >
                    <img
                      src="/assets/img/coingecko.png"
                      className="mr-3 w-4 h-4"
                    />
                    CoinGecko
                  </a>
                </Link> */}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
