import Link from 'next/link'

export const ChartHeader: React.FC = () => {
  return (
    <>
      <div className="chartz-header">
        <div className="flex justify-between flex-col h-screen">
          <div className="grid auto-rows-auto gap-y-4 ml-3 mt-6">
            <div className="z-10 w-full">
              <div className="flex items-center min-w-0 m-0 justify-between">
                <div className="min-w-0 m-0 flex p-0 items-center w-fit">
                  <Link href="/chartsoverview">
                    <a id="link" className="m-0 min-w-0">
                      <img
                        width="24px"
                        src="/assets/img/logo-2.png"
                        alt="logo"
                      />
                    </a>
                  </Link>
                  <img
                    width="84px"
                    src="/assets/icons/CRCSwap.svg"
                    alt="logo"
                    className="ml-2 mt-1"
                  />
                </div>
              </div>
            </div>
            <div className="grid auto-rows-auto gap-y-5 mt-4">
              <Link href="/chartsoverview">
                <a>
                  <div className="flex text-white opacity-60 text-sm font-medium nav-ahover">
                    <img src="/assets/icons/overview.svg" className="mr-3" />
                    Overview
                  </div>
                </a>
              </Link>
              <Link href="/chartstoken">
                <a>
                  <div className="flex text-sm opacity-60 text-white font-medium nav-ahover">
                    <img src="/assets/icons/token.svg" className="mr-3" />
                    Tokens
                  </div>
                </a>
              </Link>
              <Link href="./chartspair">
                <a>
                  <div className="flex text-sm opacity-60 text-white font-medium nav-ahover">
                    <img src="/assets/icons/pairs.svg" className="mr-3" />
                    Pairs
                  </div>
                </a>
              </Link>
              <Link href="/chartsaccount">
                <a>
                  <div className="flex text-sm opacity-100 text-white font-medium nav-ahover">
                    <img src="/assets/icons/accounts.svg" className="mr-3" />
                    Accounts
                  </div>
                </a>
              </Link>
            </div>
          </div>
          <div className="grid auto-rows-auto gap-y-2 ml-3 mb-16">
            <div className="mr-3 font-medium opacity-80 text-sm">
              <Link href="#">
                <a target="_blank" className="text-white m-0 min-w-0">
                  CRCSwap
                </a>
              </Link>
            </div>
            <div className="mr-3 font-medium opacity-80 text-sm">
              <Link href="https://app.euphoria.money">
                <a target="_blank" className="text-white m-0 min-w-0">
                  WAGMI
                </a>
              </Link>
            </div>
            <div className="mr-3 font-medium opacity-80 text-sm">
              <Link href="https://discord.gg/HucAXAD94t">
                <a target="_blank" className="text-white m-0 min-w-0">
                  Discord
                </a>
              </Link>
            </div>
            {/* <div className="mr-3 font-medium opacity-80 text-sm">
              <Link href="https://t.me/VenomDAO">
                <a target="_blank" className="text-white m-0 min-w-0">
                  VenomDAO Telegram
                </a>
              </Link>
            </div>
            <div className="mr-3 font-medium opacity-80 text-sm">
              <Link href="https://t.me/EuphoriaWAGMI">
                <a target="_blank" className="text-white m-0 min-w-0">
                  WAGMI Telegram
                </a>
              </Link>
            </div> */}
            <div className="mr-3 font-medium opacity-80 text-sm">
              <Link href="https://twitter.com/hashandblocks">
                <a target="_blank" className="text-white m-0 min-w-0">
                  Twitter
                </a>
              </Link>
            </div>
            <div className="flex w-fit cursor-pointer mt-4 text-white">
              <span>
                <div className="opacity-40">
                  <img src="/assets/icons/lightmode.svg" />
                </div>
              </span>
              <span className="px-2"> / </span>
              <span>
                <div className="opacity-80">
                  <img src="/assets/icons/darkmode.svg" />
                </div>
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="chartz-header-mobile">
        <div className="flex justify-between items-center">
          <div className="w-full z-10">
            <div className="flex items-center min-w-0 justify-between">
              <div className="flex p-0 items-center w-fit">
                <Link href="./chartsoverview">
                  <a id="link" className="text-blue m-0 min-w-0">
                    <img width="24px" src="/assets/img/logo-2.png" alt="logo" />
                  </a>
                </Link>
              </div>
              <div className="flex p-0 w-fit items-end">
                <Link href="./chartsoverview">
                  <a className="text-inherit">
                    <div className="text-sm text-white flex font-medium opacity-60 ml-3 nav-ahover">
                      Overview
                    </div>
                  </a>
                </Link>
                <Link href="./chartstoken">
                  <a className="text-inherit">
                    <div className="text-sm text-white flex font-medium opacity-60 ml-3 nav-ahover">
                      Tokens
                    </div>
                  </a>
                </Link>
                <Link href="./createpair">
                  <a className="text-inherit">
                    <div className="text-sm text-white flex font-medium opacity-60 ml-3 nav-ahover">
                      Pairs
                    </div>
                  </a>
                </Link>
                <Link href="./chartsaccount">
                  <a className="text-inherit">
                    <div className="text-sm text-white flex font-medium opacity-100 ml-3 nav-ahover">
                      Accounts
                    </div>
                  </a>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
