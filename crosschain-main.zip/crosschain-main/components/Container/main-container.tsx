import { Header } from '../Header'

export const MainContainer: React.FC<any> = ({ children }) => {
  return (
    <div className="flex items-start overflow-x-hidden flow-col">
      <Header />
      {children}
    </div>
  )
}
