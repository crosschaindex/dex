import { ChartHeader } from '../Chart-Header'

export const ChartContainer: React.FC<any> = ({ children }) => {
  return (
    <div className="w-full relative">
      <div className="overview-main">
        <ChartHeader />
        {children}
      </div>
    </div>
  )
}
