export const ChooseCoinModal: React.FC<{ show: boolean; handleClose: any }> = ({
  show,
  handleClose,
}) => {
  return (
    <div
      className="flex overflow-hidden items-center justify-center z-10 fixed inset-0 opacity-100 overlay"
      style={{ display: show ? '' : 'none' }}
    >
      <div
        aria-modal="true"
        role="dialog"
        tabIndex={-1}
        aria-label="dialog"
        className="token-modal"
      >
        <div className="flex flex-1 w-full flex-col justify-start relative">
          <div className="grid auto-rows-auto gap-y-4 p-5">
            <div className="m-0 flex w-full p-0 items-center justify-between">
              <div className="font-medium m-0 min-w-0">Select a token</div>
              <img
                src="/assets/icons/close.svg"
                className="max-w-none cursor-pointer"
                onClick={handleClose}
              />
            </div>
            <div className="m-0 min-w-0 w-full flex p-0 items-center justify-start token-address">
              <input
                type="text"
                id="token-search-input"
                placeholder="Search name or paste address"
                autoComplete="off"
                className="relative flex p-4 items-center w-full bg-none rounded-20 text-white text-lg"
              />
            </div>
          </div>
          <div className="hr-border"></div>
          <div className="flex-1 relative overflow-hidden">
            <div className="overflow-visible h-0">
              <div className="token-content">
                <div className="h-auto w-full">
                  <div className="token-item HARMONY flex justify-start gap-4 items-center">
                    <img
                      src="/assets/img/one-image.png"
                      className="sc-RcBXQ czHVaX"
                    />
                    <div className="flex items-center justify-start flex-col">
                      <div title="Harmony">ONE</div>
                      <div className="text-xs opacity-50">Harmony</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item viper-token flex justify-start gap-4 items-center">
                    <img alt="CRC logo" src="/assets/img/VIPER.png" />
                    <div>
                      <div title="CRC">CRC</div>
                      <div className="text-xs opacity-50">CRC</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item wagmi flex justify-start gap-4 items-center">
                    <img alt="WAGMI logo" src="/assets/img/WAGMI.png" />
                    <div>
                      <div title="Euphoria">WAGMI</div>
                      <div className="text-xs opacity-50">Euphoria</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item inch flex justify-start gap-4 items-center">
                    <img alt="11INCH logo" src="/assets/img/11INCH.png" />
                    <div>
                      <div title="1INCH Token">11INCH</div>
                      <div className="text-xs opacity-50">1INCH Token</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item aave flex justify-start gap-4 items-center">
                    <img alt="1AAVE logo" src="/assets/img/1AAVE.png" />
                    <div>
                      <div title="Aave Token">1AAVE</div>
                      <div className="text-xs opacity-50">Aave Token</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item bal flex justify-start gap-4 items-center">
                    <img alt="1BAL logo" src="/assets/img/1BAL.png" />
                    <div>
                      <div title="Balancer">1BAL</div>
                      <div className="text-xs opacity-50">Balancer</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item comp flex justify-start gap-4 items-center">
                    <img alt="1COMP logo" src="/assets/img/1COMP.png" />
                    <div>
                      <div title="Compound">1COMP</div>
                      <div className="text-xs opacity-50">Compound</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item cream flex justify-start gap-4 items-center">
                    <img alt="1CREAM logo" src="/assets/img/1CREAM.png" />
                    <div>
                      <div title="Cream">1CREAM</div>
                      <div className="text-xs opacity-50">Cream</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item HARMONY-1 flex justify-start gap-4 items-center">
                    <img
                      src="/assets/img/one-image.png"
                      className="sc-RcBXQ czHVaX"
                    />
                    <div className="flex items-center justify-start flex-col">
                      <div title="Harmony">ONE</div>
                      <div className="text-xs opacity-50">Harmony</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item viper-token-1 flex justify-start gap-4 items-center">
                    <img alt="CRC logo" src="/assets/img/VIPER.png" />
                    <div>
                      <div title="CRC">CRC</div>
                      <div className="text-xs opacity-50">CRC</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item wagmi-1 flex justify-start gap-4 items-center">
                    <img alt="WAGMI logo" src="/assets/img/WAGMI.png" />
                    <div>
                      <div title="Euphoria">WAGMI</div>
                      <div className="text-xs opacity-50">Euphoria</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item inch-1 flex justify-start gap-4 items-center">
                    <img alt="11INCH logo" src="/assets/img/11INCH.png" />
                    <div>
                      <div title="1INCH Token">11INCH</div>
                      <div className="text-xs opacity-50">1INCH Token</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item aave-1 flex justify-start gap-4 items-center">
                    <img alt="1AAVE logo" src="/assets/img/1AAVE.png" />
                    <div>
                      <div title="Aave Token">1AAVE</div>
                      <div className="text-xs opacity-50">Aave Token</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item bal-1 flex justify-start gap-4 items-center">
                    <img alt="1BAL logo" src="/assets/img/1BAL.png" />
                    <div>
                      <div title="Balancer">1BAL</div>
                      <div className="text-xs opacity-50">Balancer</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item comp-1 flex justify-start gap-4 items-center">
                    <img alt="1COMP logo" src="/assets/img/1COMP.png" />
                    <div>
                      <div title="Compound">1COMP</div>
                      <div className="text-xs opacity-50">Compound</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                  <div className="token-item cream-1 flex justify-start gap-4 items-center">
                    <img alt="1CREAM logo" src="/assets/img/1CREAM.png" />
                    <div>
                      <div title="Cream">1CREAM</div>
                      <div className="text-xs opacity-50">Cream</div>
                    </div>
                    <span></span>
                    <div className="justify-self-end"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="manage-content">
            <div className="manage-sub-content">
              <button>
                <div className="manage-btn-content">
                  <div className="manage-icon">
                    <img
                      src="/assets/icons/edit.svg"
                      className="max-w-none cursor-pointer"
                      onClick={handleClose}
                    />
                  </div>
                  <div className="manage-name">Manage</div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
