export const BreakdownCRC: React.FC<{ show: boolean; handleClose: any }> = ({
  show,
  handleClose,
}) => {
  return (
    <div
      id="breakdown-content"
      className="flex overflow-hidden items-center justify-center z-50 fixed inset-0  overlay transition-all"
      style={{ display: show ? '' : 'none' }}
    >
      <div
        aria-modal="true"
        role="dialog"
        tabIndex={-1}
        aria-label="dialog"
        className="wallet-modal"
      >
        <div className="grid auto-rows-auto gap-y-6 w-full">
          <div className="viper-content">
            <span className="viper-bg"></span>
            <span className="viperbg-overlay"></span>
            <div className="p-4 grid auto-rows-auto gap-y-3 z-1">
              <div className="flex min-w-0 m-0 p-0 items-center justify-between w-full">
                <div className="m-0 min-w-0 font-medium text-white">
                  Your CRC Breakdown
                </div>
                <img
                  src="/assets/icons/close.svg"
                  className="max-w-none"
                  onClick={handleClose}
                />
              </div>
            </div>
            <div className="viper-hr"></div>
            <div className="grid auto-rows-auto gap-y-2 p-4 z-1">
              <div className="grid auto-rows-auto gap-y-3">
                <div className="flex min-w-0 m-0 p-0 items-center justify-between w-full">
                  <div className="m-0 min-w-0 font-medium text-white">
                    CRC in circulation:
                  </div>
                  <div className="m-0 min-w-0 font-medium text-white">
                    177,771,811
                  </div>
                </div>
                <div className="flex min-w-0 m-0 p-0 items-center justify-between w-full">
                  <div className="m-0 min-w-0 font-medium text-white">
                    CRC total supply:
                  </div>
                  <div className="m-0 min-w-0 font-medium text-white">
                    456,020,472
                  </div>
                </div>
              </div>
            </div>
            <div className="viper-hr"></div>
            <div className="grid auto-rows-auto gap-y-2 p-4 z-1">
              <div className="grid auto-rows-auto gap-y-3">
                <div className="flex min-w-0 m-0 p-0 items-center justify-between w-full">
                  <div className="m-0 min-w-0 font-medium text-white">
                    CRC price:
                  </div>
                  <div className="m-0 min-w-0 font-medium text-white">
                    $0.0184
                  </div>
                </div>
                <div className="flex min-w-0 m-0 p-0 items-center justify-between w-full">
                  <div className="m-0 min-w-0 font-medium text-white">
                    CRC circ. market cap:
                  </div>
                  <div className="m-0 min-w-0 font-medium text-white">
                    $3,265,986
                  </div>
                </div>
                <div className="flex min-w-0 m-0 p-0 items-center justify-between w-full">
                  <div className="m-0 min-w-0 font-medium text-white">
                    CRC total market cap:
                  </div>
                  <div className="m-0 min-w-0 font-medium text-white">
                    $8,377,912
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
