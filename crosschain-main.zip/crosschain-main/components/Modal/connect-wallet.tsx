import { useRouter } from "next/router";
import { useState } from "react";
import { LoginUser } from "../../app/auth";
import { useAppDispatch, useAppSelector } from "../../app/hooks";
import { setConnectModal } from "../../store/modal";
import { authenticate } from "../../store/user";

export const ConnectWalletModal: React.FC = () => {

  const router = useRouter();
  const dispatch = useAppDispatch();
  const show = useAppSelector((state) => state.modal.connect);

  const handleClose = () => {
    dispatch(setConnectModal(false));
  };



  const [isLoading, setLoading] = useState({
    metamask: false,
    wallet_connect:false
  });
  const [error, setError] = useState<any>(null);

  const handleConnectWalletConnect = async () => {
    try {
      setLoading({ ...isLoading, wallet_connect: true });
      const referral = router.query.referral as string;
    
      // if (!window.ethereum) {
      //   window.location.href =
      //     "https://metamask.app.link/dapp/mysite.com/";
      // }

      

      await LoginUser(referral, 'wallet-connect');
      dispatch(authenticate());

      setLoading({ ...isLoading, wallet_connect: false });
      handleClose();
    } catch (err: any) {
      setError({
        title: "Error",
        message: err.message,
      });
      setLoading({ ...isLoading, wallet_connect: false });
    }
  };
  const handleConnectMetamask = async () => {
    try {
      setLoading({ ...isLoading, metamask: true });
      const referral = router.query.referral as string;
    
      // if (!window.ethereum) {
      //   window.location.href =
      //     "https://metamask.app.link/dapp/mysite.com/";
      // }
      
      await LoginUser(referral, 'metamask');
      dispatch(authenticate());

      setLoading({ ...isLoading, metamask: false });
      handleClose();
    } catch (err: any) {
      setError({
        title: "Error",
        message: err.message,
      });
      setLoading({ ...isLoading, metamask: false });
    }
  };

  
  return (
    <div
      className="flex overflow-hidden items-center justify-center z-10 fixed inset-0 opacity-100 overlay"
      style={{ display: show ? '' : 'none' }}
    >
      <div
        aria-modal="true"
        role="dialog"
        tabIndex={-1}
        aria-label="dialog"
        className="wallet-modal"
      >
        <div className="flex flowcol-nowrap m-0 p-0 w-full">
          <div className="relative">
            <div className="absolute right-4 top-3">
              <img
                src="/assets/icons/close.svg"
                className="max-w-none cursor-pointer"
                onClick={handleClose}
              />
            </div>
            <div className="flowcol-nowrap flex p-4 font-medium">
              <div>Connect to a wallet</div>
            </div>
            <div className="wallet-content">
              <div className="wallet-subcontent">
                <button disabled={isLoading.metamask} onClick={handleConnectMetamask} id="connect-METAMASK">
                  <div className="flex flowcol-nowrap justify-center h-full">
                    <div className="flex flow-nowrap text-base font-medium text-white">
                    {isLoading.metamask? "Connecting.." : "MetaMask"}

                    </div>
                  </div>
                  <div className="wallet-btnimg">
                    <img src="/assets/img/metamask.png" alt="Icon" />
                  </div>
                </button>
                <button disabled={isLoading.wallet_connect} onClick={handleConnectWalletConnect} id="connect-WALLET_CONNECT">
                  <div className="flex flowcol-nowrap justify-center h-full">
                    <div className="flex flow-nowrap text-base font-medium text-white">
                      
                      {isLoading.wallet_connect? "Connecting.." : "WalletConnect"}
                    </div>
                  </div>
                  <div className="wallet-btnimg">
                    <img src="/assets/img/walletConnectIcon.svg" alt="Icon" />
                  </div>
                </button>
                {/* <button id="connect-WALLET_LINK">
                  <div className="flex flowcol-nowrap justify-center h-full">
                    <div className="flex flow-nowrap text-base font-medium text-white">
                      Coinbase Wallet
                    </div>
                  </div>
                  <div className="wallet-btnimg">
                    <img src="/assets/img/coinbaseWalletIcon.svg" alt="Icon" />
                  </div>
                </button>
                <button id="connect-FORTMATIC">
                  <div className="flex flowcol-nowrap justify-center h-full">
                    <div
                      color="#6748FF"
                      className="flex flow-nowrap text-base font-medium text-white"
                    >
                      Fortmatic
                    </div>
                  </div>
                  <div className="wallet-btnimg">
                    <img src="/assets/img/formatic.png" alt="Icon" />
                  </div>
                </button>
                <button id="connect-Portis">
                  <div className="flex flowcol-nowrap justify-center h-full">
                    <div className="flex flow-nowrap text-base font-medium text-white">
                      Portis
                    </div>
                  </div>
                  <div className="wallet-btnimg">
                    <img src="/assets/img/portis.png" alt="Icon" />
                  </div>
                </button> */}
              </div>
              {/* <div className="flex flow-nowrap items-center justify-center mt-4 text-xs lg:mt-8 lg:text-base">
                <span>New to Harmony? &nbsp;</span>
                <a
                  target="_blank"
                  rel="noopener noreferrer"
                  href="#"
                  className="learn-more"
                >
                  Learn more about wallets
                </a>
              </div> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
