

export interface IPool {
    _id: string;
    createdAt: Date;
    primary: string;
    secondary: string;
    apy: number;
    total: number;
    pool_reward: number;
    emission_rate: number;
}

