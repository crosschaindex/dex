export type IRoles = 'user' | 'creator'

export interface IAuthUser {
    id: string
    username: string
    publicAddress: string
    role: IRoles
}

export interface IAuthJWTPayload {
    payload: IAuthUser;
  }
  

export interface IUser {
    id: string,
    username: string,
    publicAddress: string,
    email: string,
    bio: string,
    avatar: string,
    role: IRoles
}





