import type { NextPage } from 'next'
import Link from 'next/link'
import { useState } from 'react'
import { MainContainer } from '../components/Container'

const ImportPool: NextPage = () => {
  return (
    <>
      <MainContainer>
        <div className="flex flex-col w-full pt-28 items-center flex-1 overflow-x-hidden overflow-y-auto z-1 swap-content">
          <div className="grid auto-rows-auto gap-y-5 fixed right-4 top-28 w-full z-30 max-w-sm swap-div-1"></div>
          <div className="relative max-w-full h-0 m-0 hidden swap-div-2">
            <div className="flex flex-row h-full overflow-x-hidden overflow-y-auto"></div>
          </div>
          <div className="mb-5 hidden flow-nowrap items-center rounded-3 justify-evenly">
            <Link href="#/swap">
              <a
                aria-current="page"
                className="active flex items-center flow-nowrap justify-center h-12 outline-none text-xl"
                id="swap-nav-link"
              >
                Swap
              </a>
            </Link>
            <Link href="#/pool">
              <a
                className="flex items-center flow-nowrap justify-center h-12 outline-none text-xl rounded-3 text-gray"
                id="pool-nav-link"
              >
                Pool
              </a>
            </Link>
          </div>
          <div className="swap-box">
            <div className="swap-header">
              <div className="flex p-0 justify-between w-full min-w-0 items-center">
                <Link href="./pool">
                  <a>
                    <img
                      src="/assets/icons/arrow-b.svg"
                      className="max-w-none mt-0.5"
                    />
                  </a>
                </Link>
                <div className="m-0 min-w-0 text-white text-xl font-medium">
                  Import Pool
                </div>
                <div className="ml-2 flex items-center justify-center relative border-none text-left">
                  <button
                    id="opensettings-btn"
                    className="relative h-9 m-0 w-full bg-transparent border-none px-2 py-0.5 rounded-lg"
                  >
                    <img
                      src="/assets/icons/setting.svg"
                      className="max-w-none mt-0.5"
                    />
                  </button>
                  <span className="open-setting-content d-hide">
                    <div className="grid auto-rows-auto gap-y-3 p-4">
                      <div className="text-sm font-semibold m-0 min-w-0">
                        Transaction Settings
                      </div>
                      <div className="grid auto-rows-auto gap-y-3">
                        <div className="grid auto-rows-auto gap-y-2">
                          <div className="m-0 min-w-0 flex p-0 items-center justify-start w-fit">
                            <div className="lightgray font-medium text-sm m-0 min-w-0">
                              Slippage tolerance
                            </div>
                            <span className="ml-1">
                              <div className="inline-block">
                                <div className="flex items-center justify-center p-1 tollerence">
                                  <img
                                    src="/assets/icons/description.svg"
                                    className="max-w-none"
                                  />
                                </div>
                              </div>
                            </span>
                          </div>
                          <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between toller-btns">
                            <button>0.1%</button>
                            <button className="selected">0.5%</button>
                            <button>1%</button>
                            <button tabIndex={-1} className="last-btn">
                              <div className="flex w-full m-0 min-w-0 p-0 items-center justify-between">
                                <input
                                  placeholder="0.50"
                                  className="w-full h-full border-0 rounded-2 bg-darkblue text-white text-base text-right outline-none"
                                />
                                %
                              </div>
                            </button>
                          </div>
                        </div>
                        <div className="grid auto-rows-auto gap-y-2">
                          <div className="m-0 min-w-0 flex p-0 items-center justify-start w-fit">
                            <div className="lightgray font-medium text-sm m-0 min-w-0">
                              Transaction deadline
                            </div>
                            <span className="mr-1">
                              <div className="inline-block">
                                <div className="flex items-center justify-center p-1 tollerence">
                                  <img
                                    src="/assets/icons/description.svg"
                                    className="max-w-none"
                                  />
                                </div>
                              </div>
                            </span>
                          </div>
                          <div className="m-0 min-w-0 w-fit flex p-0 items-center justify-start toller-btns">
                            <button tabIndex={-1} className="first-btn">
                              <input
                                placeholder="20"
                                className="w-full h-full border-0 rounded-2 bg-darkblue text-white text-base text-right outline-none"
                              />
                            </button>
                            <div className="pl-2 m-0 min-w-0 font-medium text-sm text-white">
                              minutes
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="m-0 min-w-0 font-semibold text-sm">
                        Interface Settings
                      </div>
                      <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                        <div className="flex p-0 items-center justify-start w-fit">
                          <div className="min-w-0 lightgray font-medium text-sm">
                            Toggle Expert Mode
                          </div>
                          <span className="mr-1">
                            <div className="inline-block">
                              <div className="flex items-center justify-center p-1 tollerence">
                                <img
                                  src="/assets/icons/description.svg"
                                  className="max-w-none"
                                />
                              </div>
                            </div>
                          </span>
                        </div>
                        <button
                          id="toggle-expert-mode-button"
                          className="rounded-xl border-none flex w-fit cursor-pointer outline-none p-0 bg-darkgray"
                        >
                          <span>On</span>
                          <span className="bg-expert">Off</span>
                        </button>
                      </div>
                      <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                        <div className="flex p-0 items-center justify-start w-fit">
                          <div className="min-w-0 lightgray font-medium text-sm">
                            Disable Multihops
                          </div>
                          <span className="mr-1">
                            <div className="inline-block">
                              <div className="flex items-center justify-center p-1 tollerence">
                                <img
                                  src="/assets/icons/description.svg"
                                  className="max-w-none"
                                />
                              </div>
                            </div>
                          </span>
                        </div>
                        <button
                          id="toggle-expert-mode-button"
                          className="rounded-xl border-none flex w-fit cursor-pointer outline-none p-0 bg-darkgray"
                        >
                          <span>On</span>
                          <span className="bg-expert">Off</span>
                        </button>
                      </div>
                    </div>
                  </span>
                </div>
              </div>
            </div>
            <div id="swap-page" className="relative p-4">
              <div className="grid auto-rows-auto gap-y-5">
                <div className="flex flex-col w-full justify-start items-center">
                  <div className="m-0 min-w-0 p-5 rounded-xl w-fit create-bg">
                    <div className="m-0 min-w-0 font-medium">
                      <div className="grid auto-rows-auto gap-y-3">
                        <div className="font-normal min-w-0 m-0 lightblue">
                          Tip: Use this tool to find pairs that don&apos;t
                          automatically appear in the interface.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  id="swap-currency-input"
                  className="flex flowcol-nowrap bg-darkblue rounded-20 relative z-10"
                >
                  <div className="bg-darkblue rounded-20 swap-border">
                    <div className="flex flow-nowrap items-center py-3 pr-3 pl-4">
                      <button
                        id="swap-token-btn"
                        className="open-currency-select-button hover-border flex justify-between w-full"
                      >
                        <span className="flex items-center justify-between text-xl font-medium text-white">
                          <img src="/assets/img/one-image.png" />
                          <span className="text-xl mr-1 ml-3 token-symbol-container">
                            ONE
                          </span>
                        </span>
                        <img
                          src="/assets/icons/chevron-d.svg"
                          className="max-w-none chevlg-img h-full"
                        />
                      </button>
                    </div>
                  </div>
                </div>
                <div className="grid auto-rows-auto">
                  <div className="px-4 flex items-center justify-center w-full m-0 min-w-0 flex-wrap">
                    <div className="p-0.5">
                      <img
                        src="/assets/icons/plus.svg"
                        className="max-w-none"
                      />
                    </div>
                  </div>
                </div>
                <div
                  id="swap-currency-output"
                  className="flex flowcol-nowrap bg-darkblue rounded-20 relative z-10"
                >
                  <div className="bg-darkblue rounded-20 swap-border">
                    <div className="flex flex-nowrap items-center py-3 pr-3 pl-4">
                      <button
                        id="select-token-btn"
                        className="open-currency-select-button hover-border w-full"
                      >
                        <div className="flex items-center min-w-0 w-full justify-between m-0">
                          <div className="flex items-center">
                            <div className="ml-3 min-w-0 font-medium text-xl">
                              Select a Token
                            </div>
                          </div>
                          <img
                            src="/assets/icons/chevron-d.svg"
                            className="max-w-none chevlg-img h-full"
                          />
                        </div>
                      </button>
                    </div>
                  </div>
                </div>
                <div className="w-full m-0 min-w-0 rounded-2xl py-12 px-3 find-bg">
                  <div className="text-center m-0 min-w-0">
                    Connect to a wallet to find pools
                  </div>
                </div>
                <div className="m-0 min-w-0 w-full p-0 rounded-20">
                  <div className="grid auto-rows-auto gap-y-2 px-4"></div>
                </div>
              </div>
              <div id="swap-wallet-btn" className="mt-4">
                <button className="connect-btn">Connect Wallet</button>
              </div>
            </div>
          </div>
          <div className="goxLTc">
            <div className="grid auto-rows-auto"></div>
          </div>
          <div className="mt-20"></div>
        </div>
      </MainContainer>
    </>
  )
}

export default ImportPool
