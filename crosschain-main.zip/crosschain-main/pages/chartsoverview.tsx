import type { NextPage } from 'next'
import Link from 'next/link'
import { useState } from 'react'
import { ChartContainer, MainContainer } from '../components/Container'

const ChartsOverview: NextPage = () => {
  return (
    <ChartContainer>
      <div id="center" className="overflow-content">
        <div className="flex flex-col pt-9 pb-20 padx-12">
          <div className="analy-overlay"></div>
          <div className="analy-content">
            <div>
              <div className="grid auto-rows-auto gap-y-6 pb-6">
                <div className="m-0 min-w-0 font-medium text-2xl text-white">
                  CRCSwap Analytics
                </div>
                <div className="h-12 relative z-30 width-full">
                  <div className="analy-input">
                    <input
                      type="text"
                      placeholder="Search CRCSwap pairs and tokens..."
                    />
                    <img src="/assets/icons/search.svg" />
                  </div>
                  <div className="analy-input-content">
                    <div className="flex items-center m-0 min-w-0 p-4">
                      <span className="text-lgray">Pairs</span>
                    </div>
                    <div>
                      <Link href="#">
                        <a>
                          <div className="flex w-full min-w-0 items-center p-4 text-sm">
                            <div className="relative flex flex-row pr-4">
                              <div className="flex items-center self-center w-4 sm:w-5">
                                <img
                                  className="analy-input-img"
                                  src="/assets/img/analy-icon.png"
                                />
                              </div>
                              <div className="flex items-center justify-center absolute left-3 rounded-full">
                                <img
                                  src="/assets/img/one.png"
                                  className="analy-input-img-1"
                                />
                              </div>
                            </div>
                            <div className="text-sm font-normal text-white ml-2">
                              WAGMI-ONE Pair
                            </div>
                          </div>
                        </a>
                      </Link>
                      <Link href="#">
                        <a>
                          <div className="flex w-full min-w-0 items-center p-4 text-sm">
                            <div className="relative flex text-base flex-row">
                              <div className="flex justify-center items-center rounded-full">
                                <img
                                  src="/assets/img/one.png"
                                  className="analy-input-img-1"
                                />
                              </div>
                              <div className="flex items-center self-center w-4 sm:w-5 z-10 mr-4">
                                <img
                                  className="analy-input-img-2"
                                  src="/assets/img/VIPER.png"
                                />
                              </div>
                            </div>
                            <div className="text-sm font-normal text-white ml-2">
                              ONE-CRC Pair
                            </div>
                          </div>
                        </a>
                      </Link>
                      <Link href="#">
                        <a>
                          <div className="flex w-full min-w-0 items-center p-4 text-sm">
                            <div className="relative flex flex-row pr-4">
                              <div className="flex items-center self-center w-4 sm:w-5">
                                <img
                                  className="analy-input-img-3"
                                  src="/assets/img/comfy.png"
                                />
                              </div>
                              <div className="absolute left-3 rounded-full flex items-center justify-center">
                                <img
                                  src="/assets/img/one.png"
                                  className="analy-input-img-1"
                                />
                              </div>
                            </div>
                            <div className="text-sm font-normal text-white ml-3">
                              COMFY-ONE Pair
                            </div>
                          </div>
                        </a>
                      </Link>
                      <div className="flex items-center m-0 min-w-0 p-4">
                        <span className="text-sm text-dgray">See more...</span>
                      </div>
                    </div>
                    <div className="flex items-center m-0 min-w-0 p-4">
                      <span className="text-lgray">Tokens</span>
                    </div>
                    <div>
                      <Link href="#">
                        <a>
                          <div className="flex w-full min-w-0 items-center p-4 text-sm">
                            <div className="min-w-0 m-0 flex p-0 items-center w-fit">
                              <div className="flex items-center self-center w-4 sm:w-5">
                                <img
                                  src="/assets/img/analy-icon.png"
                                  className="pool-img mr-2"
                                />
                              </div>
                              <div className="relative text-white mr-2">
                                Euphoria
                              </div>
                              (<div className="relative text-white">WAGMI</div>)
                            </div>
                          </div>
                        </a>
                      </Link>
                      <Link href="#">
                        <a>
                          <div className="flex w-full min-w-0 items-center p-4 text-sm">
                            <div className="min-w-0 m-0 flex p-0 items-center w-fit">
                              <div className="flex items-center self-center w-4 sm:w-5">
                                <img
                                  src="/assets/img/teether.png"
                                  className="pool-img mr-2"
                                />
                              </div>
                              <div className="relative text-white mr-2">
                                Tether USD
                              </div>
                              (<div className="relative text-white">1USDT</div>)
                            </div>
                          </div>
                        </a>
                      </Link>
                      <Link href="#">
                        <a>
                          <div className="flex w-full min-w-0 items-center p-4 text-sm">
                            <div className="min-w-0 m-0 flex p-0 items-center w-fit">
                              <div className="flex items-center self-center w-4 sm:w-5">
                                <img
                                  src="/assets/img/bitcoin.png"
                                  className="pool-img mr-2"
                                />
                              </div>
                              <div className="relative text-white mr-2">
                                Wrapped BTC
                              </div>
                              (<div className="relative text-white">1WBTC</div>)
                            </div>
                          </div>
                        </a>
                      </Link>
                      <div className="flex items-center m-0 min-w-0 p-4">
                        <span className="text-dgray text-sm">See more...</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="w-full sticky top-0">
                  <div className="m-0 flex min-w-0 w-full items-center justify-between p-2">
                    <div className="min-w-0 m-0 flex p-0 items-center w-fit">
                      <div className="text-sm mr-4 min-w-0 font-medium text-white relative">
                        ONE Price:
                        <span className="font-medium">$0.12</span>
                      </div>
                      <div className="text-sm mr-4 min-w-0 font-medium text-white hidden lg:flex">
                        Transactions (24H):
                        <span className="font-medium">6,235</span>
                      </div>
                      <div className="text-sm mr-4 min-w-0 font-medium hidden md:flex text-white">
                        Pairs:
                        <span className="font-medium">3,598</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="analys-chart">
                <div className="chart-content h-full min-h-300">
                  <div className="w-full h-full">
                    <div className="relative">
                      <div id="test-idAREA">
                        <div className="sub-chart w-full">
                          <table cellSpacing={0} className="chart-table w-full">
                            <tr className="align-middle">
                              <td className="p-0"></td>
                              <td className="td-first">
                                <div className="relative w-full h-full overflow-hidden">
                                  <canvas className="chart-canvas-1"></canvas>
                                  <canvas className="chart-canvas-2"></canvas>
                                </div>
                              </td>
                              <td className="p-0">
                                <div className="td-second">
                                  <canvas className="chart-canvas-3"></canvas>
                                  <canvas className="chart-canvas-4"></canvas>
                                </div>
                              </td>
                            </tr>
                            <tr className="align-middle">
                              <td className="p-0"></td>
                              <td className="td-third">
                                <div className="relative w-full h-full overflow-hidden">
                                  <canvas className="chart-canvas-5"></canvas>
                                  <canvas className="chart-canvas-6"></canvas>
                                </div>
                              </td>
                              <td className="p-0">
                                <div className="td-fourth">
                                  <canvas className="chart-canvas-7"></canvas>
                                </div>
                              </td>
                            </tr>
                          </table>
                        </div>
                        <div
                          id="tooltip-idAREA"
                          className="w-full h-16 absolute p-2 text-xs text-white text-left z-10 pointer-events-none block font-medium -left-1 -top-3 bg-transparent charts-header"
                        >
                          <div className="my-1 text-base text-white">
                            Liquidity
                          </div>
                          <div className="text-xl text-white my-1">
                            $12,242,239
                            <span className="text-red-600 text-base ml-2.5">
                              -1.90%
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex absolute right-0 rounded h-4 w-4 p-0 bottom-0 items-center justify-center text-white">
                        <img
                          src="/assets/icons/play-btn.svg"
                          className="max-w-none"
                        />
                      </div>
                    </div>
                    <div className="w-0 invisible hidden absolute h-0"></div>
                  </div>
                </div>
                <div className="chart-content h-full">
                  <div className="w-full h-full">
                    <div className="relative">
                      <div id="test-idBAR">
                        <div className="sub-chart w-full">
                          <table cellSpacing={0} className="chart-table w-full">
                            <tr className="align-middle">
                              <td className="p-0"></td>
                              <td className="td-first">
                                <div className="relative w-full h-full overflow-hidden">
                                  <canvas className="chart-canvas-1"></canvas>
                                  <canvas className="chart-canvas-2"></canvas>
                                </div>
                              </td>
                              <td className="p-0">
                                <div className="td-second">
                                  <canvas className="chart-canvas-3"></canvas>
                                  <canvas className="chart-canvas-4"></canvas>
                                </div>
                              </td>
                            </tr>
                            <tr className="align-middle">
                              <td className="p-0"></td>
                              <td className="td-third">
                                <div className="relative w-full h-full overflow-hidden">
                                  <canvas className="chart-canvas-5"></canvas>
                                  <canvas className="chart-canvas-6"></canvas>
                                </div>
                              </td>
                              <td className="p-0">
                                <div className="td-fourth">
                                  <canvas className="chart-canvas-7"></canvas>
                                </div>
                              </td>
                            </tr>
                          </table>
                        </div>
                        <div
                          id="tooltip-idBAR"
                          className="w-full h-16 absolute p-2 text-xs text-white text-left z-10 pointer-events-none block font-medium -left-1 -top-3 bg-transparent charts-header"
                        >
                          <div className="my-1 text-base text-white">
                            Volume (24hr)
                          </div>
                          <div className="text-xl text-white my-1">
                            $388,176
                            <span className="text-red-600 text-base ml-2.5">
                              -39.64%
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex absolute right-0 rounded h-4 w-4 p-0 bottom-0 items-center justify-center text-white">
                        <img
                          src="/assets/icons/play-btn.svg"
                          className="max-w-none"
                        />
                      </div>
                    </div>
                    <div className="w-0 invisible hidden absolute h-0"></div>
                  </div>
                  <div className="min-w-0 m-0 flex p-0 items-center w-fit chart-footer">
                    <div className="w-fit p-1.5 rounded-md border text-white bg-lgray">
                      <div className="text-sm font-normal text-white">D</div>
                    </div>
                    <div className="w-fit p-1.5 rounded-md border text-white ml-1">
                      <div className="text-sm font-normal text-white">W</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mb-5 analys-chart1-mobile">
                <div>
                  <div>
                    <div className="grid auto-cols-auto gap-y-9 text-sm">
                      <div className="grid auto-rows-auto gap-y-4">
                        <div className="flex items-center justify-between w-full min-w-0">
                          <div className="text-sm font-medium text-white">
                            Volume (24hrs)
                          </div>
                          <div></div>
                        </div>
                        <div className="flex items-end justify-between w-full">
                          <div className="text-xl font-semibold text-white">
                            $375,259
                          </div>
                          <div className="text-xs font-medium text-white">
                            <div className="text-red-700 font-medium">
                              -4.82%
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="grid auto-rows-auto gap-y-5">
                        <div className="flex items-center justify-between w-full min-w-0">
                          <div className="text-sm font-medium text-white">
                            Total Liquidity
                          </div>
                          <div></div>
                        </div>
                        <div className="flex items-end justify-between w-full">
                          <div className="text-xl font-semibold text-white">
                            $12,699,111
                          </div>
                          <div className="text-xs font-medium text-white">
                            <div className="text-green-700 font-medium">
                              +3.53%
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="analys-chart2-mobile mt-1.5">
                <div className="min-height">
                  <div className="flex items-center justify-center rounded-lg py-1 pr-1.5 pl-2.5 w-28 bg-transparent relative z-20">
                    <div className="flex items-center justify-between w-full m-0 min-w-0">
                      <div className="text-sm text-white font-medium">
                        Liquidity
                      </div>
                      <div className="text-white">
                        <img
                          src="/assets/icons/chevron-d.svg"
                          className="max-w-none w-3"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="w-full h-full">
                    <div className="relative">
                      <div id="test-idAREA">
                        <div className="h-300 w-full overflow-hidden select-none"></div>
                        <div
                          id="tooltip-idAREA"
                          className="w-full h-16 absolute p-2 text-xs text-white text-left z-10 pointer-events-none block font-medium -left-1 -top-2 bg-transparent"
                        >
                          <div className="my-1 text-base text-white">
                            Liquidity
                          </div>
                          <div className="my-1 text-lg text-white">
                            $12,699,111
                            <span className="text-green-700 text-base ml-2.5">
                              +3.53%
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex absolute right-0 rounded h-4 w-4 p-0 bottom-0 items-center justify-center text-white">
                        <img
                          src="/assets/icons/play-btn.svg"
                          className="max-w-none"
                        />
                      </div>
                    </div>
                    <div className="absolute w-0 h-0 invisible hidden"></div>
                  </div>
                </div>
              </div>
              <div className="flex items-center flex-nowrap -m-2.5 h-10 w-full text-base sm:text-xl font-semibold mt-8 mb-2">
                <div className="flex min-w-0 w-full items-center justify-between m-2.5">
                  <div className="m-0 min-w-0 text-lg font-medium text-white whitespace-nowrap">
                    Top Tokens
                  </div>
                  <Link href="/tokens">
                    <a className="text-sm font-medium text-blue">See All</a>
                  </Link>
                </div>
              </div>
              <div className="chart-content mt-1.5 py-5 px-0">
                <div className="block">
                  <div className="top-token-title title-h">
                    <div className="flex items-center min-w-0 m-0">
                      <div className="text-end font-medium text-white text-sm">
                        Name
                      </div>
                    </div>
                    <div className="flex items-center min-w-0 m-0 sm-hide">
                      <div className="text-end text-white m-0 min-w-0 text-sm">
                        Symbol
                      </div>
                    </div>
                    <div className="flex items-center min-w-0 m-0">
                      <div className="text-end text-white m-0 min-w-0 text-sm">
                        Liquidity ↓
                      </div>
                    </div>
                    <div className="flex items-center min-w-0 m-0">
                      <div className="text-end text-white m-0 min-w-0 text-sm">
                        Volume (24hrs)
                      </div>
                    </div>
                    <div className="flex items-center min-w-0 m-0 lg-hide">
                      <div className="text-end text-white m-0 min-w-0 text-sm">
                        Price
                      </div>
                    </div>
                    <div className="flex items-center min-w-0 m-0 lg-hide">
                      <div className="text-end text-white m-0 min-w-0 text-sm">
                        Price Change (24hrs)
                      </div>
                    </div>
                  </div>
                  <div className="top-token-hr"></div>
                  <div className="text-sm m-0 p-0 min-w-0">
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">1</div>
                            <div className="flex items-center justify-center w-4 sm:w-5">
                              <img
                                src="/assets/img/one-image.png"
                                className="analy-input-img-1"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  ONE (Wrapped)
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide sm-hide">
                          <div className="relative text-white">ONE</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $5,913,519
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $347,919
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.12
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.20%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">2</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="/assets/img/analy-icon.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  Euphoria
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide sm-hide">
                          <div className="relative text-white">WAGMI</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $3,765,244
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $126,044
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $32.31
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.79%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">3</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="/assets/img/comfy.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">CRC</div>
                              </a>
                            </Link>
                          </div>
                        </div>

                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">CRC</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $598,787
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $128,822
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.0197
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="font-medium text-sm text-green-700">
                            +6.25%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">4</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0x702f78e81cf3dfae89648b5a9e2e1aa8db1de546.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  Comfy
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>

                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">COMFY</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $456,084
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $396.66
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.0523
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.05%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">5</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0xb4441013ea8aa3a9e35c5aca2b037e577948c59e.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  UNITE
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>

                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">UNITE</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $196,118
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $505.80
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.0742
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.56%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">6</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0x985458e523db3d53125813ed68c274899e9dfab4.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  USD Coin
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">1USDC</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $159,193
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $66,244
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $1.00
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="font-medium text-sm text-green-700">
                            +0.28%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">7</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0xfe1b516a7297eb03229a8b5afad80703911e81cb.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  Royale
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">ROY</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $147,356
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $7,364
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.0356
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -5.62%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">8</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0xbb948620fa9cd554ef9a331b13edea9b181f9d45.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  Wrapped sWAGMI
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="inline-block">
                            <div className="relative text-white">wsWA...</div>
                          </div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $137,403
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $17,649
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $845.08
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -1.88%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">9</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0xd0105cff72a89f6ff0bd47e1209bf4bdfb9dea8a.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  USHARE
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="inline-block">
                            <div className="relative text-white">USHA...</div>
                          </div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $112,020
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $207.80
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $11.35
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.28%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">10</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0x550d9923693998a6fe20801abe3f1a78e0d75089.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  Immortl
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">IMRTL</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $77,365
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $587.31
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.0003
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.75%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                  </div>
                  <div className="flex w-full justify-center my-8">
                    <div>
                      <div className="text-gray opacity-30 px-5">←</div>
                    </div>
                    <div className="text-sm font-normal text-white ml-3">
                      Page 1 of 20
                    </div>
                    <div>
                      <div className="text-gray opacity-100 px-5">→</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center flex-nowrap -m-2.5 h-10 w-full text-base sm:text-xl font-semibold mt-8 mb-2">
                <div className="flex min-w-0 w-full items-center justify-between m-2.5">
                  <div className="font-medium font-base text-white whitespace-nowrap">
                    Top Pairs
                  </div>
                  <div className="w-full flex justify-end items-center flex-nowrap -m-1">
                    <div className="min-w-0 m-1 flex p-0 items-center w-fit">
                      <input
                        name="checkbox"
                        type="checkbox"
                        className="bg-gray"
                      />
                      <div className="text-sm font-medium ml-1 cursor-pointer text-white">
                        Hide untracked pairs
                      </div>
                    </div>
                    <span className="m-1">
                      <div className="inline-block">
                        <div className="flex items-center justify-center p-1 border-none outline-none cursor-default pair-icon">
                          <img
                            src="/assets/icons/description.svg"
                            className="max-w-none"
                          />
                        </div>
                      </div>
                    </span>
                    <Link href="/pairs">
                      <a className="text-sm font-medium text-gray">See All</a>
                    </Link>
                  </div>
                </div>
              </div>
              <div className="chart-content mt-1.5 py-5 px-0">
                <div className="text-sm">
                  <div className="pairs-title title-h">
                    <div className="flex items-center min-w-0 m-0">
                      <div className="text-sm font-medium text-white">Name</div>
                    </div>
                    <div className="flex items-center">
                      <div className="text-sm font-medium text-white">
                        Liquidity ↓
                      </div>
                    </div>
                    <div className="flex items-center min-w-0 m-0 text-right">
                      <div className="text-end text-white">Volume (24hrs)</div>
                    </div>
                    <div className="flex items-center lg-hide">
                      <div className="text-end text-white">Volume (7d)</div>
                    </div>
                    <div className="flex items-center lg-hide">
                      <div className="text-end text-white">Fees (24hr)</div>
                    </div>
                    <div className="flex items-center justify-end lg-hide">
                      <div className="text-right text-white min-w-0 m-0 select-none text-sm">
                        1y Fees/ Liquidity
                      </div>
                      <span className="ml-1">
                        <div className="inline-block">
                          <div className="flex items-center justify-center p-1 border-none outline-none cursor-default pair-icon">
                            <img
                              src="/assets/icons/description.svg"
                              className="max-w-none"
                            />
                          </div>
                        </div>
                      </span>
                    </div>
                  </div>
                  <div className="top-token-hr"></div>
                  <div className="p-0 m-0 min-w-0">
                    <div>
                      <div className="pairs-title h-12">
                        <div className="flex items-center text-white font-medium">
                          <div className="w-2.5 mr-5 sm-hide">1</div>
                          <div className="relative flex flex-row mr-1 text-sm">
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                className="pair-first-img"
                                src="/assets/img/analy-icon.png"
                              />
                            </div>
                            <div className="flex items-center justify-center absolute left-2.5 rounded-full w-4 sm:w-5">
                              <img
                                src="/assets/img/one-image.png"
                                className="analy-input-img-1"
                              />
                            </div>
                          </div>
                          <Link href="#">
                            <a className="text-sm font-medium text-gray ml-3 sm:ml-5 whitespace-nowrap">
                              <div className="relative text-inherit text-sm">
                                WAGMI-ONE
                              </div>
                            </a>
                          </Link>
                        </div>
                        <div className="flex items-center text-center text-white">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$7,522,846</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$125,812</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white lg-hide">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$1,867,557</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white lg-hide">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$377.43</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white lg-hide">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">
                              <div className="font-medium text-sm text-green-700">
                                +1.83%
                              </div>
                            </div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="pairs-title h-12">
                        <div className="flex items-center text-white font-medium">
                          <div className="w-2.5 mr-5 sm-hide">2</div>
                          <div className="relative flex flex-row">
                            <div className="flex items-center justify-center rounded-full z-2 w-4 sm:w-5">
                              <img
                                src="/assets/img/one-image.png"
                                className="analy-input-img-1"
                              />
                            </div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                className="pair-first-img-1 left-2.5 absolute"
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0xea589e93ff18b1a1f1e9bac7ef3e86ab62addc79.png"
                              />
                            </div>
                          </div>
                          <Link href="#">
                            <a className="text-sm font-medium text-gray ml-3 sm:ml-5 whitespace-nowrap">
                              <div className="relative text-inherit">
                                ONE-CRC
                              </div>
                            </a>
                          </Link>
                        </div>
                        <div
                          className="f
                        lex items-center text-center text-white"
                        >
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$1,011,380</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$109,135</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white lg-hide">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$718,151</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white lg-hide">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$327.40</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white lg-hide">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">
                              <div className="font-medium text-sm text-green-700">
                                +11.82%
                              </div>
                            </div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="pairs-title h-12">
                        <div className="flex items-center text-white font-medium">
                          <div className="w-2.5 mr-5 sm-hide">3</div>
                          <div className="flex relative flex-row mr-1">
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                className="pair-first-img"
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0x702f78e81cf3dfae89648b5a9e2e1aa8db1de546.png"
                              />
                            </div>
                            <div className="flex items-center justify-center absolute rounded-full left-2.5 w-4 sm:w-5">
                              <img
                                src="/assets/img/one-image.png"
                                className="analy-input-img-1"
                              />
                            </div>
                          </div>
                          <Link href="#">
                            <a className="text-sm font-medium text-gray ml-3 sm:ml-5 whitespace-nowrap">
                              <div className="relative text-inherit">
                                COMFY-ONE
                              </div>
                            </a>
                          </Link>
                        </div>
                        <div className="flex items-center text-center text-white">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$912,098</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$396.66</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white lg-hide">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$39,238</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white lg-hide">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">$1.19</div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                        <div className="flex items-center text-center text-white lg-hide">
                          <div className="grid auto-rows-auto gap-y-0.5 text-sm opacity-100">
                            <div className="text-right">
                              <div className="font-medium text-sm text-green-700">
                                +0.05%
                              </div>
                            </div>
                            <div className="text-9 font-normal text-right"></div>
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                  </div>
                  <div className="flex w-full justify-center mt-8 mb-2">
                    <div>
                      <div className="opacity-30 px-5 text-blue">←</div>
                    </div>
                    <div className="text-sm font-normal text-white ml-3">
                      Page 1 of 21
                    </div>
                    <div>
                      <div className="opacity-100 px-5 text-blue">→</div>
                    </div>
                  </div>
                </div>
              </div>
              <span>
                <div className="m-0 min-w-0 text-lg font-medium text-white whitespace-nowrap mt-8">
                  Transactions
                </div>
              </span>
              <div className="chart-content my-4">
                <div className="transaction-title transact-h">
                  <div className="flex items-center text-sm">
                    <button className="cursor-pointer bg-transparent font-medium text-base text-white mr-3">
                      All
                    </button>
                    <button className="cursor-pointer bg-transparent font-normal text-light mr-3 text-base sm-hide">
                      Swaps
                    </button>
                    <button className="cursor-pointer bg-transparent font-normal text-light mr-3 text-base sm-hide">
                      Adds
                    </button>
                    <button className="cursor-pointer bg-transparent font-normal text-light mr-3 text-base sm-hide">
                      Removes
                    </button>
                  </div>
                  <div className="flex items-center min-w-0 m-0">
                    <div className="text-end text-white m-0 text-sm">
                      Total Value
                    </div>
                  </div>
                  <div className="flex items-center min-w-0 m-0 sm-hide">
                    <div className="text-end text-white m-0 text-sm">
                      Token Amount
                    </div>
                  </div>
                  <div className="flex items-center min-w-0 m-0 sm-hide">
                    <div className="text-end text-white m-0 text-sm">
                      Token Amount
                    </div>
                  </div>
                  <div className="items-center min-w-0 m-0 lg-hide">
                    <div className="text-sm font-normal text-white ml-3">
                      Account
                    </div>
                  </div>
                  <div className="flex items-center min-w-0 m-0">
                    <div className="text-end text-white m-0 text-sm">
                      Time ↓
                    </div>
                  </div>
                </div>
                <div className="top-token-hr"></div>
                <div className="m-0 min-w-0 p-0">
                  <div>
                    <div className="transaction-title h-12">
                      <div className="flex items-center font-medium text-sm text-white">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            Swap ONE for MAGIC
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        $3.84
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        32.1817
                        <div className="relative ml-1 text-white text-sm">
                          ONE
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        26.3699
                        <div className="relative ml-1 text-white text-sm">
                          MAGIC
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm lg-hide">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            0x90e8...5558
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        2 minutes ago
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="transaction-title h-12">
                      <div className="flex items-center font-medium text-sm text-white">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            Swap LOOT for ONE
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        $0.34
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        4,950
                        <div className="relative ml-1 text-white text-sm">
                          LOOT
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        2.83
                        <div className="relative ml-1 text-white text-sm">
                          ONE
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm lg-hide">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            0xa24b...d1f9
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        2 minutes ago
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="transaction-title h-12">
                      <div className="flex items-center font-medium text-sm text-white">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            Swap 1ETH for ONE
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        $0.18
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        0.0001
                        <div className="relative ml-1 text-white text-sm">
                          1ETH
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        1.4686
                        <div className="relative ml-1 text-white text-sm">
                          ONE
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm lg-hide">
                        <a target="_blank" rel="noopener noreferrer" href="#">
                          0xf012...32a3
                        </a>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        4 minutes ago
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="transaction-title h-12">
                      <div className="flex items-center font-medium text-sm text-white">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            Swap CRC for 1ETH
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        $0.18
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        8.886
                        <div className="relative ml-1 text-white text-sm">
                          CRC
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        0.0001
                        <div className="relative ml-1 text-white text-sm">
                          1ETH
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm lg-hide">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            0x1e77...3fa2
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        4 minutes ago
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="transaction-title h-12">
                      <div className="flex items-center font-medium text-sm text-white">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            Remove CRC and ONE
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        $0.0001
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        0.0005
                        <div className="relative ml-1 text-white text-sm">
                          CRC
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        0.0001
                        <div className="relative ml-1 text-white text-sm">
                          ONE
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm lg-hide">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            0x0891...995d
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        7 minutes ago
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="transaction-title h-12">
                      <div className="flex items-center font-medium text-sm text-white">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            Swap ONE for CRC
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        $0.0001
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        0.0001
                        <div className="relative ml-1 text-white text-sm">
                          ONE
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        0.0005
                        <div className="relative ml-1 text-white text-sm">
                          CRC
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm lg-hide">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            0xe064...4548
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        7 minutes ago
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="transaction-title h-12">
                      <div className="flex items-center font-medium text-sm text-white">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            Add CRC and ONE
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        $2.88
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        73.2433
                        <div className="relative ml-1 text-white text-sm">
                          CRC
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        12.0582
                        <div className="relative ml-1 text-white text-sm">
                          ONE
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm lg-hide">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            0x0891...995d
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        10 minutes ago
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="transaction-title h-12">
                      <div className="flex items-center font-medium text-sm text-white">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            Swap BUSD for ONE
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        $1.22
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        1.2203
                        <div className="relative ml-1 text-white text-sm">
                          BUSD
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        10.2336
                        <div className="relative ml-1 text-white text-sm">
                          ONE
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm lg-hide">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            0xf012...32a3
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        12 minutes ago
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="transaction-title h-12">
                      <div className="flex items-center font-medium text-sm text-white">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            Swap CRC for BUSD
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        $1.22
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        61.9573
                        <div className="relative ml-1 text-white text-sm">
                          CRC
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        1.2203
                        <div className="relative ml-1 text-white text-sm">
                          BUSD
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm lg-hide">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            0x4af6...7ad8
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        12 minutes ago
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="transaction-title h-12">
                      <div className="flex items-center font-medium text-sm text-white">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            Swap ONE for xCRC
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        $1.19
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        10
                        <div className="relative ml-1 text-white text-sm">
                          ONE
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm sm-hide">
                        39.7037
                        <div className="inline-block">
                          <div className="relative ml-1 text-white text-sm">
                            xVIP...
                          </div>
                        </div>
                      </div>
                      <div className="flex text-right items-center text-white text-sm lg-hide">
                        <Link href="#">
                          <a
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue"
                          >
                            0x24da...5969
                          </a>
                        </Link>
                      </div>
                      <div className="flex text-right items-center text-white text-sm">
                        15 minutes ago
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                </div>
                <div className="w-full flex justify-center mt-8 mb-2 text-sm">
                  <div>
                    <div className="opacity-30 text-blue px-5 select-none">
                      ←
                    </div>
                  </div>
                  <div className="text-sm font-normal text-white ml-3">
                    Page 1 of 15
                  </div>
                  <div>
                    <div className="opacity-100 text-blue px-5 select-none">
                      →
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ChartContainer>
  )
}

export default ChartsOverview
