import type { NextPage } from 'next'
import Link from 'next/link'
import { useState } from 'react'
import { MainContainer } from '../components/Container'

const CRCPit: NextPage = () => {
  return (
    <>
      <MainContainer>
        <div className="flex flex-col w-full pt-28 items-center flex-1 overflow-x-hidden overflow-y-auto z-1 pool-content">
          <div className="grid auto-rows-auto gap-y-5 fixed right-4 top-28 w-full z-30 max-w-sm pool-div-1"></div>
          <div className="relative max-w-full h-0 m-0 hidden pool-div-2">
            <div className="flex flex-row h-full overflow-x-hidden overflow-y-auto"></div>
          </div>
          <div className="liquid-content gap-y-6">
            <div className="liquid-content gap-y-6 relative opacity-100">
              <div className="grid auto-rows-auto gap-y-6 justify-items-center rounded-xl w-full relative">
                <div className="deposit-bg">
                  <div className="grid auto-rows-auto p-4 z-1">
                    <span className="viper-bg"></span>
                    <span className="viperoverlay-bg"></span>
                    <div className="grid auto-rows-auto gap-y-3">
                      <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                        <div className="font-semibold text-white m-0 min-w-0">
                          CRCPit - DEX fee sharing
                        </div>
                      </div>
                      <div className="flex m-0 min-w-0 w-full p-0 items-baseline justify-between">
                        <div className="text-sm text-white font-medium">
                          Stake your CRC tokens and earn 1/3rd of the generated
                          trading fees.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="unclaimed-bg">
                  <span className="viper-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="grid auto-rows-auto gap-y-2">
                    <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                      <div>
                        <div className="font-medium text-white">
                          Your x CRC Balance(1 x 1.54 CRC)
                        </div>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 items-baseline justify-between">
                      <div className="font-semibold m-0 min-w-0 text-4xl text-white">
                        0.0000
                      </div>
                      <div className="font-medium text-base"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="pit-box">
                <div className="font-medium">
                  <div className="grid auto-rows-auto gap-y-3">
                    <div className="text-center text-sm font-medium text-light">
                      <span
                        role="img"
                        aria-label="wizard-icon"
                        className="mr-2"
                      >
                        💡
                      </span>
                      <b>Important:</b> Your CRC rewards will only be visible
                      <br />
                      after you withdraw your xCRC tokens from the pool.
                      <br />
                      <br />
                      CRCpit does not have any withdrawal fees.
                      <br />
                      Tokens are also 100% unlocked when they are claimed.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-20"></div>
        </div>
      </MainContainer>
    </>
  )
}

export default CRCPit
