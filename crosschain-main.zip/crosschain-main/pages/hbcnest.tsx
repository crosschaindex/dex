import type { NextPage } from 'next'
import Link from 'next/link'
import { useState } from 'react'
import { MainContainer } from '../components/Container'

const CRCNest: NextPage = () => {
  return (
    <>
      <MainContainer>
        <div className="flex flex-col w-full pt-28 items-center flex-1 overflow-x-hidden overflow-y-auto z-1 pool-content">
          <div className="grid auto-rows-auto gap-y-5 fixed right-4 top-28 w-full z-30 max-w-sm pool-div-1"></div>
          <div className="relative max-w-full h-0 m-0 hidden pool-div-2">
            <div className="flex flex-row h-full overflow-x-hidden overflow-y-auto"></div>
          </div>
          <div className="liquid-content gap-y-6">
            <div className="stakepool-subcontent">
              <div className="liquid-provider w-full">
                <span className="viper-bg"></span>
                <span className="viperoverlay-bg"></span>
                <div className="grid auto-rows-auto p-4 z-1">
                  <div className="grid gap-y-3 auto-rows-auto">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-semibold text-white">
                        CRCNest staking
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 font-medium text-white text-sm">
                        Deposit tokens to receive rewards.
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <Link href="/archivednest">
                        <a className="cursor-pointer text-blue font-medium">
                          <button className="archived-btn">
                            Archived Pools (05)
                          </button>
                        </a>
                      </Link>
                    </div>
                  </div>
                </div>
                <span className="viper-bg"></span>
                <span className="viperoverlay-bg"></span>
              </div>
            </div>
            <div className="stakepool-subcontent gap-row-6">
              <div className="m-0 min-w-0 w-full flex p-0 justify-between items-baseline">
                <div className="mt-2 min-w-0 font-medium text-xl">CRCNest</div>
              </div>
              <input
                type="text"
                id="pools-search-input"
                placeholder="Search using name or symbol"
                className="pools-search-input"
              />
              <div className="pools-div">
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        src="/assets/img/one-image.png"
                        className="pool-img"
                      />
                      <img
                        className="pool-img-1"
                        alt="CRC logo"
                        src="/assets/img/VIPER.png"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-xl min-w-0 m-0 text-white">
                      Stake:ONE-CRC
                    </div>
                    <Link href="/deposit">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Deposit</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mb-4 ml-4 mr-4">
                    <div className="flex m-0 min-w-0 w-full items-center justify-between">
                      <div className="font-medium text-white">
                        Rewards end in
                      </div>
                      <div className="font-medium text-white">
                        <b>61 days, 6 hours, 8 minutes </b>
                      </div>
                    </div>
                    <div className="flex m-0 min-w-0 w-full items-center justify-between">
                      <div className="font-medium text-white">
                        Reward per block
                      </div>
                      <div className="font-medium text-white">
                        <b>0.1585 CRC</b>
                      </div>
                    </div>
                  </div>
                  <div className="hr-nest"></div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4 mt-3">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                      APY*
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>110%</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$936,381</b>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        className="pool-img-1"
                        alt="wsWAGMI logo"
                        src="/assets/img/WAGMI.png"
                      />
                      <img
                        className="pool-img-1"
                        alt="CRC logo"
                        src="/assets/img/VIPER.png"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-xl min-w-0 m-0 text-white">
                      Stake:wsWAGMI-VIPER
                    </div>
                    <Link href="/deposit">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Deposit</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mb-4 ml-4 mr-4">
                    <div className="flex m-0 min-w-0 w-full items-center justify-between">
                      <div className="font-medium text-white">
                        Rewards end in
                      </div>
                      <div className="font-medium text-white">
                        <b>61 days, 6 hours, 8 minutes </b>
                      </div>
                    </div>
                    <div className="flex m-0 min-w-0 w-full items-center justify-between">
                      <div className="font-medium text-white">
                        Reward per block
                      </div>
                      <div className="font-medium text-white">
                        <b>0.1585 CRC</b>
                      </div>
                    </div>
                  </div>
                  <div className="hr-nest"></div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4 mt-3">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                      APY*
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>110%</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$93,659</b>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        className="pool-img-1"
                        alt="wsWAGMI logo"
                        src="/assets/img/WAGMI.png"
                      />
                      <img
                        src="/assets/img/one-image.png"
                        className="pool-img"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-xl min-w-0 m-0 text-white">
                      Stake:wsWAGMI-ONE
                    </div>
                    <Link href="/deposit">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Deposit</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mb-4 ml-4 mr-4">
                    <div className="flex m-0 min-w-0 w-full items-center justify-between">
                      <div className="font-medium text-white">
                        Rewards end in
                      </div>
                      <div className="font-medium text-white">
                        <b>61 days, 6 hours, 8 minutes </b>
                      </div>
                    </div>
                    <div className="flex m-0 min-w-0 w-full items-center justify-between">
                      <div className="font-medium text-white">
                        Reward per block
                      </div>
                      <div className="font-medium text-white">
                        <b>0.1585 CRC</b>
                      </div>
                    </div>
                  </div>
                  <div className="hr-nest"></div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4 mt-3">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                      APY*
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>110%</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$159,991</b>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        className="pool-img-1"
                        alt="bscCOBRA logo"
                        src="/assets/img/bscCOBRA.png"
                      />
                      <img
                        className="pool-img-1"
                        alt="CRC logo"
                        src="/assets/img/VIPER.png"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-xl min-w-0 m-0 text-white">
                      Stake:bscCOBRA-CRC
                    </div>
                    <Link href="/deposit">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Deposit</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mb-4 ml-4 mr-4">
                    <div className="flex m-0 min-w-0 w-full items-center justify-between">
                      <div className="font-medium text-white">
                        Rewards end in
                      </div>
                      <div className="font-medium text-white">
                        <b>61 days, 6 hours, 8 minutes </b>
                      </div>
                    </div>
                    <div className="flex m-0 min-w-0 w-full items-center justify-between">
                      <div className="font-medium text-white">
                        Reward per block
                      </div>
                      <div className="font-medium text-white">
                        <b>0.1585 CRC</b>
                      </div>
                    </div>
                  </div>
                  <div className="hr-nest"></div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4 mt-3">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                      APY*
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>110%</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$13,639</b>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full justify-center mt-4 mb-2">
                  <div>
                    <div className="px-5 text-blue cursor-pointer">←</div>
                  </div>
                  <div className="text-base m-0 min-w-0 font-normal">
                    Page 1 of 1
                  </div>
                  <div>
                    <div className="px-5 text-blue cursor-pointer">→</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-20"></div>
        </div>
      </MainContainer>
    </>
  )
}

export default CRCNest
