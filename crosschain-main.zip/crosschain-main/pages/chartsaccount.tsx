import type { NextPage } from 'next'
import Link from 'next/link'
import { useState } from 'react'
import { ChartContainer, MainContainer } from '../components/Container'

const ChartsAccount: NextPage = () => {
  return (
    <ChartContainer>
      <div id="center" className="overflow-content">
        <div className="flex flex-col pt-9 pb-20 padx-12">
          <div className="analy-content">
            <div className="flex w-full items-center justify-between min-w-0 p-0">
              <div className="m-0 min-w-0 font-medium text-2xl text-white">
                Wallet analytics
              </div>
              <div className="z-30 relative h-12 md-inputhide">
                <div className="toptoken-input">
                  <input type="text" />
                  <img
                    src="/assets/icons/search-btn.svg"
                    className="max-w-none"
                  />
                </div>
                <div className="toptoken-inputcontent">
                  <div className="flex min-w-0 w-full m-0 items-center p-4">
                    <span className="text-blue">Pairs</span>
                  </div>
                  <div>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex relative flex-row m4 sm-hide">
                            <div className="flex items-center self-center">
                              <img
                                className="analy-input-img"
                                src="/assets/img/analy-icon.png"
                              />
                            </div>
                            <div className="flex items-center justify-center absolute left-3 rounded-full w-5">
                              <img
                                src="/assets/img/one-image.png"
                                className="analy-input-img-1"
                              />
                            </div>
                          </div>
                          <div className="text-sm font-normal min-w-0 ml-2.5">
                            WAGMI-ONE Pair
                          </div>
                        </div>
                      </a>
                    </Link>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex relative flex-row m4 sm-hide">
                            <div className="flex items-center justify-center z-2 rounded-full">
                              <img
                                src="/assets/img/one-image.png"
                                className="analy-input-img-1"
                              />
                            </div>
                            <div className="flex items-center self-center">
                              <img
                                className="analy-input-img-2"
                                src="/assets/img/logo-2.png"
                              />
                            </div>
                          </div>
                          <div className="text-sm font-normal min-w-0 ml-2.5">
                            ONE-CRC Pair
                          </div>
                        </div>
                      </a>
                    </Link>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex flex-row mr-4 relative">
                            <div className="flex items-center self-center">
                              <img
                                className="analy-input-img-3"
                                src="/assets/img/analy-icon.png"
                              />
                            </div>
                            <div className="flex items-center justify-center absolute left-3 rounded-full w-5">
                              <img
                                src="/assets/img/one-image.png"
                                className="analy-input-img-1"
                              />
                            </div>
                          </div>
                          <div className="text-sm font-normal min-w-0 ml-2.5">
                            COMFY-ONE Pair
                          </div>
                        </div>
                      </a>
                    </Link>
                    <div className="flex min-w-0 w-full m-0 items-center p-4">
                      <span className="text-blue text-sm cursor-pointer">
                        See more...
                      </span>
                    </div>
                  </div>
                  <div className="flex min-w-0 w-full m-0 items-center p-4">
                    <span className="text-blue">Tokens</span>
                  </div>
                  <div>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex items-center w-fit mr-1.5">
                            <div className="flex items-center self-center">
                              <img
                                src="/assets/img/analy-icon.png"
                                className="pool-img mr-2.5"
                              />
                            </div>
                            <div className="relative mr-1.5 text-white text-sm">
                              Euphoria
                            </div>
                            (<div className="relative text-white">WAGMI</div>)
                          </div>
                        </div>
                      </a>
                    </Link>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex items-center w-fit mr-1.5">
                            <div className="flex items-center self-center">
                              <img
                                src="/assets/img/teether.png"
                                className="pool-img mr-2.5"
                              />
                            </div>
                            <div className="relative mr-1.5 text-white text-sm">
                              Tether USD
                            </div>
                            (<div className="relative text-white">1USDT</div>)
                          </div>
                        </div>
                      </a>
                    </Link>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex items-center w-fit mr-1.5">
                            <div className="flex items-center self-center">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0x0ab43550a6915f9f67d0c454c2e90385e6497eaa.png"
                                className="pool-img mr-2.5"
                              />
                            </div>
                            <div className="relative mr-1.5 text-white text-sm">
                              BUSD Token
                            </div>
                            (
                            <div className="inline-block">
                              <div className="relative text-white">
                                bscBU...
                              </div>
                            </div>
                            )
                          </div>
                        </div>
                      </a>
                    </Link>

                    <div className="flex min-w-0 w-full m-0 items-center p-4">
                      <span className="text-blue text-sm cursor-pointer">
                        See more...
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className="grid auto-rows-auto gap-y-4">
                <div className="w-full flex items-center flex-nowrap">
                  <div className="flex flex-row items-center justify-end w-full rounded-xl">
                    <input placeholder="0x..." className="wallet-input" />
                  </div>
                  <button className="load-btn">Load Account Details</button>
                </div>
                <div className="grid auto-rows-auto gap-y-3">
                  <div className="save-box">
                    <div className="accounts-content">
                      <div className="text-white text-sm font-medium justify-end">
                        Saved Accounts
                      </div>
                    </div>
                    <div className="account-hr"></div>
                    <div className="text-sm font-medium mt-4 text-blue">
                      No saved accounts
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="chart-content mt-1.5 py-5">
              <div>
                <div className="top-position-title h-fit pt-0 px-0 pb-4">
                  <div className="flex items-center justify-start m-0 sm-hide">
                    <div className="text-white font-medium text-sm">#</div>
                  </div>
                  <div className="flex items-center justify-start m-0">
                    <div className="text-white font-medium text-sm">
                      Account
                    </div>
                  </div>
                  <div className="flex items-center justify-end text-right">
                    <div className="text-white font-medium text-sm">Pair</div>
                  </div>
                  <div className="flex items-center justify-end text-right">
                    <div className="text-white font-medium text-sm">Value</div>
                  </div>
                </div>
                <div className="top-token-hr"></div>
                <div className="m-0 min-w-0">
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        1
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        2
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        3
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        4
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        5
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a
                            className="text-blue ml-4 text-sm font-medium whitespace-nowrap"
                            href="#"
                          >
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        6
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        7
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        8
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        9
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        10
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        11
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                  <div>
                    <div className="top-position-title h-12">
                      <div className="font-medium items-center text-center text-white justify-end sm-hide">
                        12
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-md">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            0x46be04e4ff71f807908a0678e3c9228b9343e030
                          </a>
                        </Link>
                      </div>
                      <div className="items-center text-center justify-start font-medium text-white link-hide-lg">
                        <Link href="#">
                          <a className="text-blue text-sm font-medium whitespace-nowrap">
                            0x46...e030
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        <Link href="#">
                          <a className="text-blue ml-4 text-sm font-medium whitespace-nowrap">
                            <div className="flex items-center w-fit">
                              <div className="relative flex-row mr-4 sm-hide">
                                <div className="flex items-center text-center">
                                  <span
                                    className="text-base rounded-full z-2"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                                <div className="flex items-center text-center">
                                  <span
                                    className="absolute left-2 rounded-full text-base"
                                    role="img"
                                    aria-label="face"
                                  >
                                    🤔
                                  </span>
                                </div>
                              </div>
                              TONY-Matt
                            </div>
                          </a>
                        </Link>
                      </div>
                      <div className="flex items-center text-center justify-end">
                        $59.39b
                      </div>
                    </div>
                    <div className="top-token-hr"></div>
                  </div>
                </div>
                <div className="flex w-full justify-center mt-8 mb-2">
                  <div>
                    <div className="opacity-30 px-5 select-none text-blue">
                      ←
                    </div>
                  </div>
                  <div className="text-sm font-normal text-white">
                    Page 1 of 1
                  </div>
                  <div>
                    <div className="opacity-30 px-5 select-none text-blue">
                      →
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ChartContainer>
  )
}

export default ChartsAccount
