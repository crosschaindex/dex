import type { NextPage } from 'next'
import Link from 'next/link'
import { useState } from 'react'
import { MainContainer } from '../components/Container'

const Manage: NextPage = () => {
  return (
    <>
      <MainContainer>
        <div className="flex flex-col w-full pt-28 items-center flex-1 overflow-x-hidden overflow-y-auto z-1 pool-content">
          <div className="grid auto-rows-auto gap-y-5 fixed right-4 top-28 w-full z-30 max-w-sm pool-div-1"></div>
          <div className="relative max-w-full h-0 m-0 hidden pool-div-2">
            <div className="flex flex-row h-full overflow-x-hidden overflow-y-auto"></div>
          </div>
          <div className="liquid-content gap-y-6">
            <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between gap-6">
              <div className="min-w-0 font-medium text-xl m-0">
                ONE-CRC Liquidity Mining
              </div>
              <div className="relative flex flex-row">
                <img src="/assets/img/one-image.png" className="pool-img" />
                <img
                  className="pool-img-1"
                  alt="CRC logo"
                  src="/assets/img/VIPER.png"
                />
              </div>
            </div>
            <div className="m-0 min-w-0 w-full flex p-0 items-center justify-center gap-6">
              <div className="grid auto-rows-auto rounded-xl w-full relative overflow-hidden bg-transparent border p-4 z-1">
                <div className="grid auto-rows-auto gap-y-2">
                  <div className="min-w-0 m-0 font-normal text-base">
                    Total Deposits
                  </div>
                  <div className="m-0 min-w-0 font-medium text-xl text-white">
                    $954,792
                  </div>
                </div>
              </div>
              <div className="grid auto-rows-auto rounded-xl w-full relative overflow-hidden bg-transparent border p-4 z-1">
                <div className="grid auto-rows-auto gap-y-2">
                  <div className="min-w-0 m-0 font-normal text-base">
                    Emission Rate
                  </div>
                  <div className="m-0 min-w-0 font-medium text-xl text-white">
                    1.838 CRC / block
                  </div>
                </div>
              </div>
            </div>
            <div className="liquid-content gap-y-6 relative opacity-100">
              <div className="grid auto-rows-auto gap-y-6 justify-items-center rounded-xl w-full relative">
                <div className="deposit-bg">
                  <div className="grid auto-rows-auto p-4 z-1">
                    <span className="viper-bg"></span>
                    <span className="viperoverlay-bg"></span>
                    <div className="grid auto-rows-auto gap-y-3">
                      <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                        <div className="font-semibold text-white m-0 min-w-0">
                          Your liquidity deposits
                        </div>
                      </div>
                      <div className="m-0 min-w-0 w-full flex p-0 items-baseline justify-between">
                        <div className="m-0 min-w-0 font-semibold text-white text-4xl">
                          0
                        </div>
                        <div className="m-0 min-w-0 font-medium text-white">
                          VENOM-LP ONE-CRC
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="unclaimed-bg">
                  <span className="viper-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="grid auto-rows-auto gap-y-2">
                    <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                      <div>
                        <div className="font-medium text-white">
                          Your unclaimed CRC
                        </div>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 items-baseline justify-between">
                      <div className="font-semibold m-0 min-w-0 text-4xl">
                        0.0000
                      </div>
                      <div className="font-medium text-base"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-center font-medium text-sm text-light">
                <span role="img" aria-label="wizard-icon" className="mr-2">
                  ⭐️
                </span>
                When you deposit or withdraw the contract will automatically
                claim CRC on your behalf.
                <br />
                <span role="img" aria-label="wizard-icon" className="mr-2">
                  💡
                </span>
                The unclaimed CRC amount listed above is your total rewards -
                <br />
                when claiming 95% will be locked and 5% will be immediately
                accessible.
              </div>
            </div>
          </div>
          <div className="mt-20"></div>
        </div>
      </MainContainer>
    </>
  )
}

export default Manage
