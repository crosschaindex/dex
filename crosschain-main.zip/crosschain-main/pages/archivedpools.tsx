import type { NextPage } from 'next'
import Link from 'next/link'
import { useState } from 'react'
import { MainContainer } from '../components/Container'


const ArchivedPool: NextPage = () => {


  return (
    <MainContainer>
        <div className="flex flex-col w-full pt-28 items-center flex-1 overflow-x-hidden overflow-y-auto z-1 pool-content">
          <div className="grid auto-rows-auto gap-y-5 fixed right-4 top-28 w-full z-30 max-w-sm pool-div-1"></div>
          <div className="relative max-w-full h-0 m-0 hidden pool-div-2">
            <div className="flex flex-row h-full overflow-x-hidden overflow-y-auto"></div>
          </div>
          <div className="liquid-content gap-y-6 justify-center">
            <div className="stakepool-subcontent">
              <div className="liquid-provider">
                <span className="viper-bg"></span>
                <span className="viperoverlay-bg"></span>
                <div className="grid auto-rows-auto p-4 z-1">
                  <div className="grid gap-y-3 auto-rows-auto">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-semibold text-white">
                        CRC liquidity mining
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 font-medium text-white text-sm">
                        Deposit your Liquidity Provider tokens to receive CRC,
                        the CRC Protocol governance token.
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <Link href="/pools">
                        <a className="cursor-pointer text-blue font-medium">
                          <button className="archived-btn">
                            View active pools
                          </button>
                        </a>
                      </Link>
                    </div>
                  </div>
                </div>
                <span className="viper-bg"></span>
                <span className="viperoverlay-bg"></span>
              </div>
            </div>
            <div className="stakepool-subcontent gap-row-6">
              <div className="m-0 min-w-0 w-full flex p-0 justify-between items-baseline">
                <div className="mt-2 min-w-0 font-medium text-xl">
                  Pools - archived
                </div>
              </div>
              <input
                type="text"
                id="pools-search-input"
                placeholder="Search using name or symbol"
                className="pools-search-input"
              />
              <div className="pools-div">
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        src="/assets/img/one-image.png"
                        className="pool-img"
                      />
                      <img
                        className="pool-img-1"
                        alt="CRC logo"
                        src="/assets/img/VIPER.png"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-2xl min-w-0 m-0 text-white">
                      ONE-CRC
                    </div>
                    <Link href="/manage">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Manage</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$936,381</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Pool reward allocation
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        91.93%
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Emission rate
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        1.838 CRC / block
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        className="pool-img-1"
                        alt="wsWAGMI logo"
                        src="/assets/img/WAGMI.png"
                      />
                      <img
                        className="pool-img-1"
                        alt="CRC logo"
                        src="/assets/img/VIPER.png"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-2xl min-w-0 m-0 text-white">
                      wsWAGMI-CRC
                    </div>
                    <Link href="/manage">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Manage</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$93,659</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Pool reward allocation
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        2.554%
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Emission rate
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        0.05107 CRC / block
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        className="pool-img-1"
                        alt="wsWAGMI logo"
                        src="/assets/img/WAGMI.png"
                      />
                      <img
                        src="/assets/img/one-image.png"
                        className="pool-img"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-2xl min-w-0 m-0 text-white">
                      wsWAGMI-ONE
                    </div>
                    <Link href="/manage">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Manage</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$159,991</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Pool reward allocation
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        2.554%
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Emission rate
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        0.05107 CRC / block
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        className="pool-img-1"
                        alt="bscCOBRA logo"
                        src="/assets/img/bscCOBRA.png"
                      />
                      <img
                        className="pool-img-1"
                        alt="CRC logo"
                        src="/assets/img/VIPER.png"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-2xl min-w-0 m-0 text-white">
                      bscCOBRA-CRC
                    </div>
                    <Link href="/manage">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Manage</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$13,639</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Pool reward allocation
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        2.554%
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Emission rate
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        0.05107 CRC / block
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        className="pool-img-1"
                        alt="ONEUSD logo"
                        src="/assets/img/1USDC.png"
                      />
                      <img
                        className="pool-img-1"
                        alt="1USDC logo"
                        src="/assets/img/ONEUSD.png"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-2xl min-w-0 m-0 text-white">
                      ONEUSD-1USDC
                    </div>
                    <Link href="/manage">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Manage</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$8,380</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Pool reward allocation
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        0.1021%
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Emission rate
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        0.002042 CRC / block
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        className="pool-img-1"
                        alt="ONEUSD logo"
                        src="/assets/img/ONEUSD.png"
                      />
                      <img
                        src="/assets/img/one-image.png"
                        className="pool-img"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-2xl min-w-0 m-0 text-white">
                      ONEUSD-ONE
                    </div>
                    <Link href="/manage">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Manage</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$9,740</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Pool reward allocation
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        0.1021%
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Emission rate
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        0.002042 CRC / block
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        className="pool-img-1"
                        alt="MAI logo"
                        src="/assets/img/MAI.png"
                      />
                      <img
                        className="pool-img-1"
                        alt="CRC logo"
                        src="/assets/img/VIPER.png"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-2xl min-w-0 m-0 text-white">
                      MAI-CRC
                    </div>
                    <Link href="/manage">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Manage</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$9,820</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Pool reward allocation
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        0.1021%
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Emission rate
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        0.002042 CRC / block
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pool-divcontent">
                  <span className="pooldiv-bg"></span>
                  <span className="viperoverlay-bg"></span>
                  <div className="pool-header">
                    <div className="relative flex flex-row">
                      <img
                        className="pool-img-1"
                        alt="MAI logo"
                        src="/assets/img/MAI.png"
                      />
                      <img
                        src="/assets/img/one-image.png"
                        className="pool-img"
                      />
                    </div>
                    <div className="ml-2 font-semibold text-2xl min-w-0 m-0 text-white">
                      MAI-ONE
                    </div>
                    <Link href="/manage">
                      <a className="cursor-pointer font-medium text-blue w-full">
                        <button className="deposit-btn">Manage</button>
                      </a>
                    </Link>
                  </div>
                  <div className="flex justify-between flex-col gap-3 mx-4 mb-4">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Total deposited
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        <b>$44,812</b>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Pool reward allocation
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        0.1021%
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center dis-hide">
                      <div className="m-0 min-w-0 font-medium text-white">
                        Emission rate
                      </div>
                      <div className="m-0 min-w-0 font-medium text-white">
                        0.002042 CRC / block
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full justify-center mt-4 mb-2">
                  <div>
                    <div className="px-5 text-blue cursor-pointer">←</div>
                  </div>
                  <div className="text-base m-0 min-w-0 font-normal">
                    Page 1 of 1
                  </div>
                  <div>
                    <div className="px-5 text-blue cursor-pointer">→</div>
                  </div>
                </div>
              </div>
              <div className="m-0 min-w-0 font-medium text-sm text-center text-light">
                <span role="img" aria-label="wizard-icon" className="mr-2">
                  ☁️
                </span>
                The base emission rate is currently <b>2</b> CRC per block.
                <br />
                <b>60</b>
                CRC will be minted every minute given the current emission
                schedule.
                <br />
                <br />
                <div className="m-0 min-w-0 text-xs text-center font-medium">
                  * = The APY is calculated using a very simplified formula, it
                  might not fully represent the exact APY
                  <br />
                  when factoring in the dynamic emission schedule and the
                  locked/unlocked rewards vesting system.
                </div>
              </div>
            </div>
          </div>
          <div className="mt-20"></div>
        </div>
     
     
    </MainContainer>
  )
}

export default ArchivedPool
