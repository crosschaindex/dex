import "../styles/style.css";
import "../styles/index.css";
import { Provider } from "react-redux";
import type { AppProps } from "next/app";
import store from "../store";
import { UserProvider } from "../provider/UserContext";
import Head from "next/head";

function MyApp({ Component, pageProps }: AppProps) {
  return (
    <>
      <Head>
        <title>CRC</title>
      </Head>
      <Provider store={store}>
        <UserProvider>
          <Component {...pageProps} />
        </UserProvider>
      </Provider>
    </>
  );
}



export default MyApp;
