import { NextApiRequest, NextApiResponse } from 'next'
import dbConnect from '../../../lib/database/connect'
import Liquidity from '../../../models/Liquidity'
import Pool from '../../../models/Pool'
import Transaction from '../../../models/Transaction'
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    const {
        method,
        body,
        
    } = req


    // connecting to database
    await dbConnect()

    switch (method) {
        case 'POST':
            try {
                const {
                    hash,
                    amount,
                    from,
                    currency
                } = body



                const newTransaction = new Transaction({
                    hash,
                    amount,
                    from,
                })

                const savedTransaction = await newTransaction.save()

                //ADD TO USER DEPOST?

                const pool = await Pool.findOne({ secondary: currency.toLowerCase() })

                //check if liquidty exsit 
                const liquidity = await Liquidity.findOne({ user: from, pool: pool._id })
                if (!liquidity) {
                    //create a new liquidity
                    const newLiquidity = new Liquidity({
                        user: from,
                        pool: pool._id,
                        deposit: amount,
                        reward: 0
                    })
                    await newLiquidity.save()

                } else {
                    let deposit = liquidity.deposit

                    liquidity.deposit = parseFloat(deposit) + parseFloat(amount)

                    await liquidity.save()
                }


                //   res.status(200).json({ success: true, pool:  savedPool})
                res.status(200).json({ success: true, transaction: savedTransaction })
            } catch (error) {
                res.status(400).json({ success: false, error })
            }
            break
        case 'GET':
            try {
                const transactions = await Transaction.find({})
                res.status(200).json({ success: true, transactions })
            } catch (error) {
                //  console.log(error)
                res.status(400).json({ success: false, error })
            }
            break;

        default:
            res.status(400).json({ success: false })
            break
    }
}


