import { NextApiRequest, NextApiResponse } from 'next'
import dbConnect from '../../../lib/database/connect'
import User from '../../../models/User'
import { USER_TOKEN } from '../../../constants'
import { verifyToken } from '../../../lib/auth'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const {
    method,
    body,
    cookies
  } = req


  const { publicAddress, referral } = body

  // connecting to database
  try {
    await dbConnect()
  } catch (err) {
    console.log(err)
  }


  switch (method) {
    case 'POST':
      try {

        const user = await _checkUser(publicAddress, referral)
        res.status(200).json({ success: true, user })
      } catch (error) {
        console.log(error)
        res.status(400).json({ success: false, error })
      }
      break
    case 'GET':
      try {
        const user = await _getUser(cookies)
        res.status(200).json({ success: true, user })
      } catch (error) {
        //  console.log(error)
        res.status(400).json({ success: false, error })
      }
      break;

    default:
      res.status(400).json({ success: false })
      break
  }
}


const _checkUser = (publicAddress: string, referral: string) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (!publicAddress) throw new Error("invalid publickey")

      let user = await User.findOne({ publicAddress })
      if (!user) {
        console.log("no user")

        const newUser = new User({
          nonce: Math.floor(Math.random() * 10000),
          publicAddress: publicAddress,
          username: '',
          email: '',
          bio: '',
        })
        if (referral) {
          newUser.referral = referral.toLowerCase()
        }

        user = await newUser.save()
      }
      resolve(user)

    } catch (err) {
      reject(err)
    }
  })
}
const _getUser = (cookies: any) => {
  return new Promise(async (resolve, reject) => {
    try {

      const token = cookies[USER_TOKEN]
      //console.log("token: " + token)
      if (!token) throw new Error("no token")
      const user = await verifyToken(token)
      // console.log(user)
      resolve(user)

    } catch (err) {
      reject(err)
    }
  })
}