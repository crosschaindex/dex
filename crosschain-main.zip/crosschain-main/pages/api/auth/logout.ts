import { NextApiRequest, NextApiResponse } from "next"
import Cookies from 'cookies'
import { USER_TOKEN } from "../../../constants"

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    const {
        method,
    } = req


    switch (method) {
        case 'GET':
            try {
              //  res.clearCookie("key");
              const cookies = new Cookies(req, res)
              cookies.set(USER_TOKEN, '', {httpOnly: true,maxAge: 0})
              // const cookie = cookies.get[USER_TOKEN]
                 //if (!cookie) 
                //  cookies.set(USER_TOKEN, '', {httpOnly: true})
                // res.redirect('/')

                res.status(200).json({ success: true })
            } catch (error) {
                res.status(400).json({ success: false, error })
            }
            break

        default:
            res.status(400).json({ success: false })
            break
    }
}

