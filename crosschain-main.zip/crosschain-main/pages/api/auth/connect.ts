import { NextApiRequest, NextApiResponse } from 'next'
import { recoverPersonalSignature } from 'eth-sig-util'
import { bufferToHex } from 'ethereumjs-util'
import jwt from 'jsonwebtoken'
import { APP_NAME, JWT_SECRET_KEY, USER_TOKEN } from '../../../constants'
import dbConnect from '../../../lib/database/connect'
import User from '../../../models/User'
import Cookies from 'cookies'
import { IAuthUser } from '../../../types'



export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    const {
        method,
        body
    } = req

    // destructuring body 
    const { publicAddress, signature } = body

    // connecting to database
    await dbConnect()


    switch (method) {
        case 'POST':
            try {
                const token = await _verifySignature(publicAddress, signature)
                // const cookie = req.cookies[USER_TOKEN]
                // if (!cookie)res.cookie(USER_TOKEN, token, { httpOnly: true })
                
                const cookies = new Cookies(req, res)

               // const cookie = cookies.get[USER_TOKEN]
                  //if (!cookie) 
                  cookies.set(USER_TOKEN, token, {httpOnly: true})

                res.status(200).json({ success: true, token })
            } catch (error) {
                res.status(400).json({ success: false, error })
            }
            break

        default:
            res.status(400).json({ success: false })
            break
    }
}


const _verifySignature = (publicAddress: string, signature: string): Promise<string> => {
    return new Promise(async (resolve, reject) => {
        try {

            if (!publicAddress) throw new Error("invalid publickey")
            if (!signature) throw new Error("invalid signature")


            let user = await User.findOne({ publicAddress: publicAddress })
            if (!user) throw new Error(`User with publicAddress ${publicAddress} is not found in database`)

            const msg = `Please sign this message to connect to ${APP_NAME}(${user.nonce})`;
            // We now are in possession of msg, publicAddress and signature. We
            // will use a helper from eth-sig-util to extract the address from the signature
            const msgBufferHex = bufferToHex(Buffer.from(msg, 'utf8'));
            const address = recoverPersonalSignature({
                data: msgBufferHex,
                sig: signature,
            });
            // The signature verification is successful if the address found with
            // sigUtil.recoverPersonalSignature matches the initial publicAddress
            if (address.toLowerCase() !== publicAddress.toLowerCase()) {
                throw new Error('Signature verification failed');
            }
            user.nonce = Math.floor(Math.random() * 10000);
            user = await user.save();

            //TODO: add expire add and check in a middleware
            let payload: IAuthUser = {
                id: user._id,
                username: user.username,
                publicAddress: address.toLowerCase(),
                role: user.role

            }

            //   let accessToken = await jwt.sign({ payload: payload, }, config.secret, { algorithm: config.algorithms[0], })
            const token = jwt.sign({ payload }, JWT_SECRET_KEY, { expiresIn: '6h' })

            if (!token) throw new Error('Empty token');

            resolve(token) 

        } catch (err) {
            reject(err)
        }
    })
}