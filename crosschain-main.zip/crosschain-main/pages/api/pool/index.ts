import { NextApiRequest, NextApiResponse } from 'next'
import dbConnect from '../../../lib/database/connect'
import Pool from '../../../models/Pool'
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const {
    method,
    body,
    cookies
  } = req

  
  // connecting to database
  await dbConnect()

  switch (method) {
    case 'POST':
      try {

        //TODO: comment this function after creating pools

        // const {primary,
        //     secondary,
        //     apy,
        //     total,
        //     pool_reward,
        //     emission_rate} = body


        // const newPool = new Pool({
        //     primary,
        //     secondary,
        //     apy,
        //     total,
        //     pool_reward,
        //     emission_rate
        // })

        // const savedPool = await newPool.save()

     //   res.status(200).json({ success: true, pool:  savedPool})
        res.status(200).json({ success: true, pool:  null})
      } catch (error) {
        res.status(400).json({ success: false , error})
      }
      break
    case 'GET':
      try {
        const pools = await Pool.find({})
        res.status(200).json({ success: true, pools })
      } catch (error) {
      //  console.log(error)
        res.status(400).json({ success: false , error})
      }
      break;

    default:
      res.status(400).json({ success: false })
      break
  }
}


