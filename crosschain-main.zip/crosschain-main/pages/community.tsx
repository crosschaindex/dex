import type { NextPage } from 'next'
import Link from 'next/link'
import { useState } from 'react'
import { MainContainer } from '../components/Container'

const Community: NextPage = () => {
  return (
    <>
      <MainContainer>
        <div className="flex flex-col w-full pt-28 items-center flex-1 overflow-x-hidden overflow-y-auto z-1 pool-content">
          <div className="grid auto-rows-auto gap-y-5 fixed right-4 top-28 w-full z-30 max-w-sm pool-div-1"></div>
          <div className="relative max-w-full h-0 m-0 hidden pool-div-2">
            <div className="flex flex-row h-full overflow-x-hidden overflow-y-auto"></div>
          </div>
          <div className="liquid-content gap-y-6">
            <div className="stakepool-subcontent">
              <div className="liquid-provider">
                <span className="viper-bg"></span>
                <span className="viperoverlay-bg"></span>
                <div className="grid auto-rows-auto p-4 z-1">
                  <div className="grid gap-y-3 auto-rows-auto">
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 min-w-0 font-semibold text-white">
                        Community Pools liquidity mining
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <div className="m-0 font-medium text-white text-sm">
                        Deposit your Liquidity Provider tokens to receive
                        rewards.
                      </div>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                      <Link href="#">
                        <a className="cursor-pointer text-blue font-medium">
                          <button className="archived-btn">Archived(10)</button>
                        </a>
                      </Link>
                    </div>
                  </div>
                </div>
                <span className="viper-bg"></span>
                <span className="viperoverlay-bg"></span>
              </div>
            </div>
            <div className="stakepool-subcontent gap-row-6">
              <div className="m-0 min-w-0 w-full flex p-0 justify-between items-baseline">
                <div className="mt-2 min-w-0 font-medium text-xl">
                  Community Pools
                </div>
              </div>
              <input
                type="text"
                id="pools-search-input"
                placeholder="Search using name or symbol"
                className="pools-search-input"
              />
            </div>
          </div>
          <div className="mt-20"></div>
        </div>
      </MainContainer>
    </>
  )
}

export default Community
