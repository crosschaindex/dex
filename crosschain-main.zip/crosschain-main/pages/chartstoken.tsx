import type { NextPage } from 'next'
import Link from 'next/link'
import { useState } from 'react'
import { ChartContainer, MainContainer } from '../components/Container'

const ChartsToken: NextPage = () => {
  return (
    <ChartContainer>
      <div id="center" className="overflow-content">
        <div className="flex flex-col pt-9 pb-20 padx-12">
          <div className="analy-content">
            <div className="flex w-full items-center justify-between min-w-0 p-0">
              <div className="m-0 min-w-0 font-medium text-2xl text-white">
                Top Tokens
              </div>
              <div className="z-30 relative h-12 md-inputhide">
                <div className="toptoken-input">
                  <input type="text" />
                  <img
                    src="/assets/icons/search-btn.svg"
                    className="max-w-none"
                  />
                </div>
                <div className="toptoken-inputcontent">
                  <div className="flex min-w-0 w-full m-0 items-center p-4">
                    <span className="text-blue">Pairs</span>
                  </div>
                  <div>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex relative flex-row mr-4">
                            <div className="flex items-center self-center">
                              <img
                                className="analy-input-img"
                                src="/assets/img/analy-icon.png"
                              />
                            </div>
                            <div className="flex items-center justify-center absolute left-3 rounded-full w-5">
                              <img
                                src="/assets/img/one-image.png"
                                className="analy-input-img-1"
                              />
                            </div>
                          </div>
                          <div className="text-sm font-normal min-w-0 ml-2.5">
                            WAGMI-ONE Pair
                          </div>
                        </div>
                      </a>
                    </Link>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex relative flex-row mr-4">
                            <div className="flex items-center justify-center z-2 rounded-full">
                              <img
                                src="/assets/img/one-image.png"
                                className="analy-input-img-1"
                              />
                            </div>
                            <div className="flex items-center self-center">
                              <img
                                className="analy-input-img-2"
                                src="/assets/img/logo-2.png"
                              />
                            </div>
                          </div>
                          <div className="text-sm font-normal min-w-0 ml-2.5">
                            ONE-CRC Pair
                          </div>
                        </div>
                      </a>
                    </Link>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex flex-row mr-4 relative">
                            <div className="flex items-center self-center">
                              <img
                                className="analy-input-img-3"
                                src="/assets/img/analy-icon.png"
                              />
                            </div>
                            <div className="flex items-center justify-center absolute left-3 rounded-full w-5">
                              <img
                                src="/assets/img/one-image.png"
                                className="analy-input-img-1"
                              />
                            </div>
                          </div>
                          <div className="text-sm font-normal min-w-0 ml-2.5">
                            COMFY-ONE Pair
                          </div>
                        </div>
                      </a>
                    </Link>
                    <div className="flex min-w-0 w-full m-0 items-center p-4">
                      <span className="text-blue text-sm cursor-pointer">
                        See more...
                      </span>
                    </div>
                  </div>
                  <div className="flex min-w-0 w-full m-0 items-center p-4">
                    <span className="text-blue">Tokens</span>
                  </div>
                  <div>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex items-center w-fit mr-1.5">
                            <div className="flex items-center self-center">
                              <img
                                src="/assets/img/analy-icon.png"
                                className="pool-img mr-2.5"
                              />
                            </div>
                            <div className="relative mr-1.5 text-white text-sm">
                              Euphoria
                            </div>
                            (<div className="relative text-white">WAGMI</div>)
                          </div>
                        </div>
                      </a>
                    </Link>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex items-center w-fit mr-1.5">
                            <div className="flex items-center self-center">
                              <img
                                src="
                              </Link>/assets/img/teether.png"
                                className="pool-img mr-2.5"
                              />
                            </div>
                            <div className="relative mr-1.5 text-white text-sm">
                              Tether USD
                            </div>
                            (<div className="relative text-white">1USDT</div>)
                          </div>
                        </div>
                      </a>
                    </Link>
                    <Link href="#">
                      <a>
                        <div className="flex w-full items-center p-4 text-sm">
                          <div className="flex items-center w-fit mr-1.5">
                            <div className="flex items-center self-center">
                              <img
                                src="
                              </Link>https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0x0ab43550a6915f9f67d0c454c2e90385e6497eaa.png"
                                className="pool-img mr-2.5"
                              />
                            </div>
                            <div className="relative mr-1.5 text-white text-sm">
                              BUSD Token
                            </div>
                            (
                            <div className="sc-jDwBTQ dQsmjY">
                              <div className="relative text-white">
                                bscBU...
                              </div>
                            </div>
                            )
                          </div>
                        </div>
                      </a>
                    </Link>
                    <div className="flex min-w-0 w-full m-0 items-center p-4">
                      <span className="text-blue text-sm cursor-pointer">
                        See more...
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className="chart-content mt-1.5 py-5 px-0">
                <div className="block">
                  <div className="top-token-title title-h">
                    <div className="flex items-center min-w-0 m-0">
                      <div className="text-end font-medium text-white text-sm">
                        Name
                      </div>
                    </div>
                    <div className="flex items-center min-w-0 m-0 sm-hide">
                      <div className="text-end text-white m-0 min-w-0 text-sm">
                        Symbol
                      </div>
                    </div>
                    <div className="flex items-center min-w-0 m-0">
                      <div className="text-end text-white m-0 min-w-0 text-sm">
                        Liquidity ↓
                      </div>
                    </div>
                    <div className="flex items-center min-w-0 m-0">
                      <div className="text-end text-white m-0 min-w-0 text-sm">
                        Volume (24hrs)
                      </div>
                    </div>
                    <div className="flex items-center min-w-0 m-0 lg-hide">
                      <div className="text-end text-white m-0 min-w-0 text-sm">
                        Price
                      </div>
                    </div>
                    <div className="flex items-center min-w-0 m-0 lg-hide">
                      <div className="text-end text-white m-0 min-w-0 text-sm">
                        Price Change (24hrs)
                      </div>
                    </div>
                  </div>
                  <div className="top-token-hr"></div>
                  <div className="text-sm m-0 p-0 min-w-0">
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">1</div>
                            <div className="flex items-center justify-center w-4 sm:w-5">
                              <img
                                src="/assets/img/one-image.png"
                                className="analy-input-img-1"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  ONE (Wrapped)
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide sm-hide">
                          <div className="relative text-white">ONE</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $5,913,519
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $347,919
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.12
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.20%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">2</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="/assets/img/analy-icon.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  Euphoria
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide sm-hide">
                          <div className="relative text-white">WAGMI</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $3,765,244
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $126,044
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $32.31
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.79%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">3</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="/assets/img/comfy.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">CRC</div>
                              </a>
                            </Link>
                          </div>
                        </div>

                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">CRC</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $598,787
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $128,822
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.0197
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="font-medium text-sm text-green-700">
                            +6.25%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">4</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0x702f78e81cf3dfae89648b5a9e2e1aa8db1de546.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  Comfy
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>

                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">COMFY</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $456,084
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $396.66
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.0523
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.05%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">5</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0xb4441013ea8aa3a9e35c5aca2b037e577948c59e.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  UNITE
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>

                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">UNITE</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $196,118
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $505.80
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.0742
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.56%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">6</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0x985458e523db3d53125813ed68c274899e9dfab4.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  USD Coin
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">1USDC</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $159,193
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $66,244
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $1.00
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="font-medium text-sm text-green-700">
                            +0.28%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">7</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0xfe1b516a7297eb03229a8b5afad80703911e81cb.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  Royale
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">ROY</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $147,356
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $7,364
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.0356
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -5.62%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">8</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0xbb948620fa9cd554ef9a331b13edea9b181f9d45.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  Wrapped sWAGMI
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="inline-block">
                            <div className="relative text-white">wsWA...</div>
                          </div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $137,403
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $17,649
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $845.08
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -1.88%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">9</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0xd0105cff72a89f6ff0bd47e1209bf4bdfb9dea8a.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  USHARE
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="inline-block">
                            <div className="relative text-white">USHA...</div>
                          </div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $112,020
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $207.80
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $11.35
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.28%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                    <div>
                      <div className="top-token-title h-12">
                        <div className="flex items-center font-medium m-0 text-white overflow-hidden">
                          <div className="flex text-sm w-full m-0 p-0 items-center">
                            <div className="mr-4 w-2.5 sm-hide">10</div>
                            <div className="flex items-center self-center w-4 sm:w-5">
                              <img
                                src="https://d1xrz6ki9z98vb.cloudfront.net/venomswap/tokens/viper/0x550d9923693998a6fe20801abe3f1a78e0d75089.png"
                                className="pool-img mr-2"
                              />
                            </div>
                            <Link href="#">
                              <a className="text-sm font-medium text-gray ml-4 whitespace-nowrap">
                                <div className="relative text-inherit">
                                  Immortl
                                </div>
                              </a>
                            </Link>
                          </div>
                        </div>
                        <div className="flex font-medium items-center text-center text-white text-sm sm-hide">
                          <div className="relative text-white">IMRTL</div>
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white">
                          $77,365
                        </div>
                        <div className="min-w-0 m-0 items-center text-center text-white">
                          $587.31
                        </div>
                        <div className="font-medium items-center text-center text-white text-sm lg-hide">
                          $0.0003
                        </div>
                        <div className="flex min-w-0 m-0 items-center text-center text-white lg-hide">
                          <div className="text-red-700 font-medium text-sm">
                            -2.75%
                          </div>
                        </div>
                      </div>
                      <div className="top-token-hr"></div>
                    </div>
                  </div>
                  <div className="flex w-full justify-center my-8">
                    <div>
                      <div className="text-gray opacity-30 px-5">←</div>
                    </div>
                    <div className="text-sm font-normal text-white ml-3">
                      Page 1 of 4
                    </div>
                    <div>
                      <div className="text-gray opacity-100 px-5">→</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ChartContainer>
  )
}

export default ChartsToken
