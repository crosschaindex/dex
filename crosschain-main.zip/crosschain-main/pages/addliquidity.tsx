import type { GetServerSideProps, NextPage } from "next";
import Link from "next/link";
import React, { useState } from "react";
import { useAppDispatch, useAppSelector } from "../app/hooks";
import { createTransactionsApi } from "../clientApi";
import { MainContainer } from "../components/Container";
import { setConnectModal } from "../store/modal";
import { TransferEth, TransferTronUsdt, TransferUsdt } from "../web3/methods";

const Addliq: NextPage = () => {
  const dispatch = useAppDispatch();

  const user = useAppSelector((state) => state.user);

  const ethPrice = 1333.15;

  const [primaryValue, setPrimaryValue] = useState<string>("0");
  const [secondaryValue, setSecondaryValue] = useState<string>("0");
  const [liqSubHeader, setLiqSubHeader] = useState(false);
  const [primaryCurrency, setPrimaryCurrency] = useState("ETH");
  const [alert, setAlert] = useState("");
  const [isLoading, setLoading] = useState(false);

  const handleConnect = (e: React.MouseEvent<HTMLElement>) => {
    e.preventDefault();
    dispatch(setConnectModal(true));
  };

  // hash,
  // amount,
  // from,
  // poolId

  const handleDeposit = async () => {
    try {
      if (parseFloat(secondaryValue) < 1000) {
        setAlert("minimum deposit 1,000 CRC");
        return;
      }

      setLoading(true);
      let hash;
      if (primaryCurrency === "ETH") {
        hash = await TransferEth(primaryValue);
      } else if(primaryCurrency === "USDT(TRX)"){
        hash = await TransferTronUsdt(primaryValue);
      }else{
        hash = await TransferUsdt(primaryValue);

      }

      let data = {
        hash,
        amount: secondaryValue,
        from: user.user.publicAddress,
        currency: primaryCurrency,
      };
      await createTransactionsApi(data);
      setLoading(false);
    } catch (err) {
      setLoading(false);
      console.log(err);
    }
  };

  const handleInputChange = (e: React.FormEvent<HTMLInputElement>) => {
    const name = (e.target as HTMLInputElement).name;
    const value = (e.target as HTMLInputElement).value;

    if (alert != "") {
      setAlert("");
    }

    if (primaryCurrency === "ETH") {
      if (name === "secondaryValue") {
        setSecondaryValue(value);
        setPrimaryValue((parseFloat(value) / ethPrice).toFixed(4));
      } else {
        setPrimaryValue(value);
        setSecondaryValue((parseFloat(value) * ethPrice).toFixed(2));
      }
    } else {
      setSecondaryValue(value);
      setPrimaryValue(value);
    }
  };

  const handleOnChangePrimaryCurreny = (e:any, currency:string)=>{
    e.preventDefault()
    setPrimaryCurrency(currency)
    setLiqSubHeader(false)
    setSecondaryValue("0")
  }

  return (
    <MainContainer>
      <div className="flex flex-col w-full pt-28 items-center flex-1 overflow-x-hidden overflow-y-auto z-1 swap-content">
        <div className="swap-box">
          <div className="swap-header">
            <div className="flex p-0 justify-between w-full min-w-0 items-center">
              <Link href="/pool">
                <a>
                  <img src="/assets/icons/arrow-b.svg" className="max-w-none" />
                </a>
              </Link>
              <div className="m-0 min-w-0 text-white text-xl font-medium">
                Add Liquidity
              </div>
              <div className="ml-2 flex items-center justify-center relative border-none text-left">
                <button
                  id="opensettings-btn"
                  className="relative h-9 m-0 w-full bg-transparent border-none px-2 py-0.5 rounded-lg"
                >
                  <img
                    src="/assets/icons/setting.svg"
                    className="max-w-none mt-0.5"
                  />
                </button>
                <span
                  id="open-setting-content"
                  className="open-setting-content d-hide"
                >
                  <div className="grid auto-rows-auto gap-y-3 p-4">
                    <div className="text-sm font-semibold m-0 min-w-0">
                      Transaction Settings
                    </div>
                    <div className="grid auto-rows-auto gap-y-3">
                      <div className="grid auto-rows-auto gap-y-2">
                        <div className="m-0 min-w-0 flex p-0 items-center justify-start w-fit">
                          <div className="lightgray font-medium text-sm m-0 min-w-0">
                            Slippage tolerance
                          </div>
                          <span className="ml-1">
                            <div className="inline-block">
                              <div className="flex items-center justify-center p-1 tollerence">
                                <img
                                  src="/assets/icons/description.svg"
                                  className="max-w-none"
                                />
                              </div>
                            </div>
                          </span>
                        </div>
                        <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between toller-btns">
                          <button>0.1%</button>
                          <button className="selected">0.5%</button>
                          <button>1%</button>
                          <button tabIndex={-1} className="last-btn">
                            <div className="flex w-full m-0 min-w-0 p-0 items-center justify-between">
                              <input
                                placeholder="0.50"
                                className="w-full h-full border-0 rounded-2 bg-darkblue text-white text-base text-right outline-none"
                              />
                              %
                            </div>
                          </button>
                        </div>
                      </div>
                      <div className="grid auto-rows-auto gap-y-2">
                        <div className="m-0 min-w-0 flex p-0 items-center justify-start w-fit">
                          <div className="lightgray font-medium text-sm m-0 min-w-0">
                            Transaction deadline
                          </div>
                          <span className="mr-1">
                            <div className="inline-block">
                              <div className="flex items-center justify-center p-1 tollerence">
                                <img
                                  src="/assets/icons/description.svg"
                                  className="max-w-none"
                                />
                              </div>
                            </div>
                          </span>
                        </div>
                        <div className="m-0 min-w-0 w-fit flex p-0 items-center justify-start toller-btns">
                          <button tabIndex={-1} className="first-btn">
                            <input
                              placeholder="20"
                              className="w-full h-full border-0 rounded-2 bg-darkblue text-white text-base text-right outline-none"
                            />
                          </button>
                          <div className="pl-2 m-0 min-w-0 font-medium text-sm text-white">
                            minutes
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 font-semibold text-sm">
                      Interface Settings
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                      <div className="flex p-0 items-center justify-start w-fit">
                        <div className="min-w-0 lightgray font-medium text-sm">
                          Toggle Expert Mode
                        </div>
                        <span className="mr-1">
                          <div className="inline-block">
                            <div className="flex items-center justify-center p-1 tollerence">
                              <img
                                src="/assets/icons/description.svg"
                                className="max-w-none"
                              />
                            </div>
                          </div>
                        </span>
                      </div>
                      <button
                        id="toggle-expert-mode-button"
                        className="rounded-xl border-none flex w-fit cursor-pointer outline-none p-0 bg-darkgray"
                      >
                        <span>On</span>
                        <span className="bg-expert">Off</span>
                      </button>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                      <div className="flex p-0 items-center justify-start w-fit">
                        <div className="min-w-0 lightgray font-medium text-sm">
                          Disable Multihops
                        </div>
                        <span className="mr-1">
                          <div className="inline-block">
                            <div className="flex items-center justify-center p-1 tollerence">
                              <img
                                src="/assets/icons/description.svg"
                                className="max-w-none"
                              />
                            </div>
                          </div>
                        </span>
                      </div>
                      <button
                        id="toggle-expert-mode-button"
                        className="rounded-xl border-none flex w-fit cursor-pointer outline-none p-0 bg-darkgray"
                      >
                        <span>On</span>
                        <span className="bg-expert">Off</span>
                      </button>
                    </div>
                  </div>
                </span>
              </div>
            </div>
          </div>
          <div id="swap-page" className="relative p-4">
            <div className="grid auto-rows-auto gap-y-5">
              <div className="flex flex-col w-full justify-start items-center">
                <div className="m-0 min-w-0 p-5 rounded-xl w-fit create-bg">
                  <div className="m-0 min-w-0 font-medium">
                    <div className="grid auto-rows-auto gap-y-3">
                      <div className="font-normal min-w-0 m-0 lightblue">
                        <b>Tip:</b> When you add liquidity, you will receive
                        pool tokens representing your position. These tokens
                        automatically earn fees proportional to your share of
                        the pool, and can be redeemed at any time.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                id="swap-currency-input"
                className="flex flowcol-nowrap bg-darkblue rounded-20 relative z-10"
              >
                <div className="bg-darkblue rounded-20 swap-border">
                  <div className="flex flow-nowrap items-center text-white text-xs px-4 pt-3 pb-0">
                    <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                      <div className="m-0 min-w-0 font-medium text-sm lightgray">
                        Input
                      </div>
                      <div className="cursor-pointer text-sm text-light font-medium hidden">
                        Balance: 0
                      </div>
                    </div>
                  </div>
                  <div className="flex flow-nowrap items-center py-3 pr-3 pl-4">
                    <input
                      className="token-amount-input"
                      inputMode="decimal"
                      title="Token Amount"
                      autoComplete="off"
                      autoCorrect="off"
                      type="text"
                      pattern="^[0-9]*[.,]?[0-9]*$"
                      placeholder="0.0"
                      minLength={1}
                      maxLength={79}
                      spellCheck="false"
                      value={primaryValue}
                      onChange={handleInputChange}
                      name="primaryValue"
                    />
                    <div className="relative">
                      <button
                        onClick={() => setLiqSubHeader(!liqSubHeader)}
                        id="swap-token-btn"
                        className="open-currency-select-button hover-bg relative"
                      >
                        <span className="flex items-center justify-between text-xl font-medium text-white">
                          <img
                            src={`/assets/icons/tokens/${primaryCurrency.toLowerCase()}.svg`}
                            alt={primaryCurrency.toLowerCase()}
                          />
                          <span className="text-xl mr-1 ml-3 token-symbol-container">
                            {primaryCurrency}
                          </span>
                          <img
                            src="/assets/icons/chevron-d.svg"
                            className="max-w-none chev-img"
                          />
                        </span>
                      </button>
                      <span
                        className={
                          liqSubHeader ? "liq-content" : "liq-content d-hide"
                        }
                      >
                        <span
                          onClick={(e) => handleOnChangePrimaryCurreny(e, "USDT")}
                          className="flex items-center ml-1 mr-4 text-base font-medium text-white cursor-pointer"
                        >
                          <img
                            src={`/assets/icons/tokens/usdt.svg`}
                            alt="usdt"
                            className="w-5 h-5"
                          />
                          <span className="text-base mr-1 ml-3 token-symbol-container">
                            USDT
                          </span>
                        </span>
                        <span
                          onClick={(e) => handleOnChangePrimaryCurreny(e,"USDT(TRX)")}
                          className="flex items-center ml-1 mr-4 text-base font-medium mt-3 text-white cursor-pointer"
                        >
                          <img
                            src={`/assets/icons/tokens/usdt.svg`}
                            alt="usdt"
                            className="w-5 h-5"
                          />
                          <span className="text-base mr-1 ml-3 token-symbol-container">
                          USDT(TRX)
                          </span>
                        </span>
                        <span
                          onClick={(e) => handleOnChangePrimaryCurreny(e,"ETH")}
                          className="flex items-center ml-1 mr-4 text-base font-medium text-white mt-3 cursor-pointer"
                        >
                          <img
                            src={`/assets/icons/tokens/eth.svg`}
                            alt="usdt"
                            className="w-5 h-5"
                          />
                          <span className="text-base mr-1 ml-3 token-symbol-container">
                            ETH
                          </span>
                        </span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="grid auto-rows-auto">
                <div className="px-4 flex items-center justify-center w-full m-0 min-w-0 flex-wrap">
                  <div className="p-0.5">
                    <img src="/assets/icons/plus.svg" className="max-w-none" />
                  </div>
                </div>
              </div>
              <div
                id="swap-currency-output"
                className="flex flowcol-nowrap bg-darkblue rounded-20 relative "
              >
                <div className="bg-darkblue rounded-20 swap-border">
                  <div className="flex flow-nowrap items-center text-white text-xs px-4 pt-3 pb-0">
                    <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                      <div className="m-0 min-w-0 font-medium text-sm lightgray">
                        Input
                      </div>
                      <div className="cursor-pointer text-sm text-light font-medium hidden">
                        -
                      </div>
                    </div>
                  </div>
                  <div className="flex flow-nowrap items-center py-3 pr-3 pl-4">
                    <input
                      className="token-amount-input"
                      inputMode="decimal"
                      title="Token Amount"
                      autoComplete="off"
                      autoCorrect="off"
                      type="text"
                      pattern="^[0-9]*[.,]?[0-9]*$"
                      placeholder="0.0"
                      minLength={1}
                      maxLength={79}
                      spellCheck="false"
                      value={secondaryValue}
                      onChange={handleInputChange}
                      name="secondaryValue"
                    />
                    <button
                      id="swap-token-btn"
                      className="open-currency-select-button hover-bg"
                    >
                      <span className="flex items-center justify-between text-xl font-medium text-white">
                        <img src={`/assets/icons/tokens/CRC.svg`} alt="CRC" />
                        <span className="text-xl mr-1 ml-3 token-symbol-container">
                          CRC
                        </span>
                        {/* <img
                          src="/assets/icons/chevron-d.svg"
                          className="max-w-none chev-img"
                        /> */}
                      </span>
                    </button>
                  </div>
                </div>
              </div>
              <div className="m-0 min-w-0 w-full p-0 rounded-20">
                <div className="grid auto-rows-auto gap-y-2 px-4"></div>
              </div>
            </div>

            {user.status === "authenticated" ? (
              <div id="swap-wallet-btn" className="mt-4">
                <button
                  disabled={isLoading}
                  onClick={handleDeposit}
                  className="connect-btn"
                >
                  {isLoading ? "Depositing.." : "Deposit"}
                </button>
              </div>
            ) : (
              <div
                id="swap-wallet-btn"
                onClick={handleConnect}
                className="mt-4"
              >
                <button className="connect-btn">Connect Wallet</button>
              </div>
            )}

            {alert && (
              <div id="swap-wallet-btn" className="mt-4 opacity-40">
                <button
                  style={{ background: "#250000" }}
                  className="connect-btn"
                >
                  {alert}
                </button>
              </div>
            )}
          </div>
        </div>
        <div className="goxLTc">
          <div className="grid auto-rows-auto"></div>
        </div>
        <div className="mt-20"></div>
      </div>
    </MainContainer>
  );
};

export default Addliq;
