import type { NextPage } from 'next'
import { useState } from 'react'
import { useAppDispatch, useAppSelector } from '../app/hooks'
import { MainContainer } from '../components/Container'
import { ChooseCoinModal } from '../components/Modal/choose-coin'
import { setConnectModal } from '../store/modal'

const Home: NextPage = () => {
  const dispatch = useAppDispatch()

  const user = useAppSelector((state) => state.user)

  const [chooseCoinShow, setChooseCoinShow] = useState(false)

  const handleConnect = (e: React.MouseEvent<HTMLElement>) => {
    e.preventDefault()
    dispatch(setConnectModal(true))
  }

  return (
    <MainContainer>
      <div className="flex flex-col w-full pt-28 items-center flex-1 overflow-x-hidden overflow-y-auto z-1 swap-content">
        <div className="swap-box">
          <div className="swap-header">
            <div className="flex p-0 justify-between w-full min-w-0 items-center">
              <div className="font-medium m-0 min-w-0 text-white">Swap</div>
              <div className="ml-2 flex items-center justify-center relative border-none text-left">
                <button
                  id="open-settings-dialog-button"
                  className="relative h-9 m-0 w-full bg-transparent border-none px-2 py-0.5 rounded-lg"
                >
                  <img
                    src="/assets/icons/setting.svg"
                    className="max-w-none mt-0.5"
                  />
                </button>
                <span className="open-setting-content d-hide">
                  <div className="grid auto-rows-auto gap-y-3 p-4">
                    <div className="text-sm font-semibold m-0 min-w-0">
                      Transaction Settings
                    </div>
                    <div className="grid auto-rows-auto gap-y-3">
                      <div className="grid auto-rows-auto gap-y-2">
                        <div className="m-0 min-w-0 flex p-0 items-center justify-start w-fit">
                          <div className="lightgray font-medium text-sm m-0 min-w-0">
                            Slippage tolerance
                          </div>
                          <span className="ml-1">
                            <div className="inline-block">
                              <div className="flex items-center justify-center p-1 tollerence">
                                <img
                                  src="/assets/icons/description.svg"
                                  className="max-w-none"
                                />
                              </div>
                            </div>
                          </span>
                        </div>
                        <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between toller-btns">
                          <button>0.1%</button>
                          <button className="selected">0.5%</button>
                          <button>1%</button>
                          <button tabIndex={-1} className="last-btn">
                            <div className="flex w-full m-0 min-w-0 p-0 items-center justify-between">
                              <input
                                placeholder="0.50"
                                className="w-full h-full border-0 rounded-2 bg-darkblue text-white text-base text-right outline-none"
                              />
                              %
                            </div>
                          </button>
                        </div>
                      </div>
                      <div className="grid auto-rows-auto gap-y-2">
                        <div className="m-0 min-w-0 flex p-0 items-center justify-start w-fit">
                          <div className="lightgray font-medium text-sm m-0 min-w-0">
                            Transaction deadline
                          </div>
                          <span className="mr-1">
                            <div className="inline-block">
                              <div className="flex items-center justify-center p-1 tollerence">
                                <img
                                  src="/assets/icons/description.svg"
                                  className="max-w-none"
                                />
                              </div>
                            </div>
                          </span>
                        </div>
                        <div className="m-0 min-w-0 w-fit flex p-0 items-center justify-start toller-btns">
                          <button tabIndex={-1} className="first-btn">
                            <input
                              placeholder="20"
                              className="w-full h-full border-0 rounded-2 bg-darkblue text-white text-base text-right outline-none"
                            />
                          </button>
                          <div className="pl-2 m-0 min-w-0 font-medium text-sm text-white">
                            minutes
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="m-0 min-w-0 font-semibold text-sm">
                      Interface Settings
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                      <div className="flex p-0 items-center justify-start w-fit">
                        <div className="min-w-0 lightgray font-medium text-sm">
                          Toggle Expert Mode
                        </div>
                        <span className="mr-1">
                          <div className="inline-block">
                            <div className="flex items-center justify-center p-1 tollerence">
                              <img
                                src="/assets/icons/description.svg"
                                className="max-w-none"
                              />
                            </div>
                          </div>
                        </span>
                      </div>
                      <button
                        id="toggle-expert-mode-button"
                        className="rounded-xl border-none flex w-fit cursor-pointer outline-none p-0 bg-darkgray"
                      >
                        <span>On</span>
                        <span className="bg-expert">Off</span>
                      </button>
                    </div>
                    <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                      <div className="flex p-0 items-center justify-start w-fit">
                        <div className="min-w-0 lightgray font-medium text-sm">
                          Disable Multihops
                        </div>
                        <span className="mr-1">
                          <div className="inline-block">
                            <div className="flex items-center justify-center p-1 tollerence">
                              <img
                                src="/assets/icons/description.svg"
                                className="max-w-none"
                              />
                            </div>
                          </div>
                        </span>
                      </div>
                      <button
                        id="toggle-expert-mode-button"
                        className="rounded-xl border-none flex w-fit cursor-pointer outline-none p-0 bg-darkgray"
                      >
                        <span>On</span>
                        <span className="bg-expert">Off</span>
                      </button>
                    </div>
                  </div>
                </span>
              </div>
            </div>
          </div>
          <div id="swap-page" className="relative p-4">
            <div className="grid auto-rows-auto gap-y-3">
              <div
                id="swap-currency-input"
                className="flex flowcol-nowrap bg-darkblue rounded-20 relative z-10"
              >
                <div className="bg-darkblue rounded-20 swap-border">
                  <div className="flex flow-nowrap items-center text-white text-xs px-4 pt-3 pb-0">
                    <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                      <div className="m-0 min-w-0 font-medium text-sm lightgray">
                        From
                      </div>
                    </div>
                  </div>
                  <div className="flex flow-nowrap items-center py-3 pr-3 pl-4">
                    <input
                      className="token-amount-input"
                      inputMode="decimal"
                      title="Token Amount"
                      autoComplete="off"
                      autoCorrect="off"
                      type="text"
                      pattern="^[0-9]*[.,]?[0-9]*$"
                      placeholder="0.0"
                      minLength={1}
                      maxLength={79}
                      spellCheck="false"
                    />
                    <button
                      onClick={() => setChooseCoinShow(true)}
                      className="open-currency-select-button hover-bg"
                    >
                      <span className="flex items-center justify-between text-xl font-medium text-white">
                        <img
                          src="/assets/img/one-image.png"
                          className="sc-RcBXQ czHVaX"
                        />
                        <span className="text-xl mr-1 ml-3 token-symbol-container">
                          ONE
                        </span>
                        <img
                          src="/assets/icons/chevron-d.svg"
                          className="max-w-none h-2 w-3 chev-img"
                        />
                      </span>
                    </button>
                  </div>
                </div>
              </div>
              <div className="grid auto-rows-auto">
                <div className="px-4 flex items-center justify-center w-full m-0 min-w-0 flex-wrap">
                  <div className="p-0.5">
                    <img
                      src="/assets/icons/arrow-d.svg"
                      className="max-w-none"
                    />
                  </div>
                </div>
              </div>
              <div
                id="swap-currency-output"
                className="flex flowcol-nowrap bg-darkblue rounded-20 relative z-10"
              >
                <div className="bg-darkblue rounded-20 swap-border">
                  <div className="flex flow-nowrap items-center text-white text-xs px-4 pt-3 pb-0">
                    <div className="m-0 min-w-0 w-full flex p-0 items-center justify-between">
                      <div className="m-0 min-w-0 font-medium text-sm lightgray">
                        To
                      </div>
                    </div>
                  </div>
                  <div className="flex flow-nowrap items-center py-3 pr-3 pl-4">
                    <input
                      className="token-amount-input"
                      inputMode="decimal"
                      title="Token Amount"
                      autoComplete="off"
                      autoCorrect="off"
                      type="text"
                      pattern="^[0-9]*[.,]?[0-9]*$"
                      placeholder="0.0"
                      minLength={1}
                      maxLength={79}
                      spellCheck="false"
                    />
                    <button className="open-currency-select-button bg-blue">
                      <span className="flex items-center justify-between">
                        <span className="token-symbol-container text-base mx-1">
                          Select a token
                        </span>
                        <img
                          src="/assets/icons/chevron-d.svg"
                          className="max-w-none h-2 w-3 chev-img"
                        />
                      </span>
                    </button>
                  </div>
                </div>
              </div>
              <div className="m-0 min-w-0 w-full p-0 rounded-20">
                <div className="grid auto-rows-auto gap-y-2 px-4"></div>
              </div>
            </div>
            <div className="mt-4">
              {user.status === 'authenticated' ? (
                <button className="connect-btn">Swap</button>
              ) : (
                <button onClick={handleConnect} className="connect-btn">
                  Connect Wallet
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="goxLTc">
          <div className="grid auto-rows-auto"></div>
        </div>
        <div className="mt-20"></div>
      </div>

      <ChooseCoinModal
        show={chooseCoinShow}
        handleClose={() => setChooseCoinShow(false)}
      />
    </MainContainer>
  )
}

export default Home
