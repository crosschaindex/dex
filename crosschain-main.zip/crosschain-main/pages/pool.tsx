import type { NextPage } from "next";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../app/hooks";
import { MainContainer } from "../components/Container";
import { getpools } from "../store/pool";

const Pool: NextPage = () => {
  const dispatch = useAppDispatch()

  const user = useAppSelector((state) => state.user);


  // const pools = useAppSelector((state) => state.pool.pools);

  // useEffect(() => {
  //   dispatch(getpools());
  // }, []);


  return (
    <MainContainer>
      <div className="flex flex-col w-full pt-28 items-center flex-1 overflow-x-hidden overflow-y-auto z-1 pool-content">
        <div className="grid auto-rows-auto gap-y-5 fixed right-4 top-28 w-full z-30 max-w-sm pool-div-1"></div>
        <div className="relative max-w-full h-0 m-0 hidden pool-div-2">
          <div className="flex flex-row h-full overflow-x-hidden overflow-y-auto"></div>
        </div>

        <div className="liquid-content">
          <div className="liquid-provider">
            <span className="viper-bg"></span>
            <span className="viperbg-overlay"></span>
            <div className="grid auto-rows-auto p-4 z-1">
              <div className="grid auto-rows-auto gap-y-3">
                <div className="m-0 p-0 min-w-0 w-full flex items-center justify-between">
                  <div className="font-semibold m-0 min-w-0 text-white">
                    Liquidity provider rewards
                  </div>
                </div>
                <div className="m-0 p-0 min-w-0 w-full flex items-center justify-between">
                  <div className="font-medium text-sm m-0 min-w-0 text-white">
                    Liquidity providers earn a 0.2% fee on all trades
                    proportional to their share of the pool. Fees are added to
                    the pool, accrue in real time and can be claimed by
                    withdrawing your liquidity.
                  </div>
                </div>
              </div>
            </div>
            <span className="viper-bg"></span>
            <span className="viperbg-overlay"></span>
          </div>
          <div className="grid auto-rows-auto gap-y-6">
            <div className="grid auto-rows-auto gap-y-6 w-full">
              <div className="m-0 mt-4 min-w-0 w-full flex items-center justify-between p-0 flexflow-reverse">
                <span>
                  <div className="text-lg justify-self-start mt-2 min-w-0 font-medium">
                    Your liquidity
                  </div>
                </span>
                <div className="flex m-0 p-0 items-center justify-start w-fit gap-2 liquid-btns">
                  <Link href="/addliquidity">
                    <a>Create a pair</a>
                  </Link>
                  <Link href="/addliquidity">
                    <a id="join-pool-button" className="liquid-last">
                      <div className="css-xy7yfl">Add Liquidity</div>
                    </a>
                  </Link>
                </div>
              </div>
              {user.status !== "authenticated" && (
                <div className="p-10 m-0 min-w-0 w-full rounded-2xl">
                  <div className="m-0 min-w-0 font-normal text-center text-dgray">
                    Connect to a wallet to view your liquidity.
                  </div>
                </div>
              )}

              {/* <div className="grid auto-rows-auto gap-y-3 items-center">
                <div className="py-2 text-sm text-center m-0 min-w-0">
                  Don&apos;t see a pool you joined?
                  <Link href="/pool">
                    <a
                      id="import-pool-link"
                      className="text-blue font-medium cursor-pointer"
                    >
                      Import it.
                    </a>
                  </Link>
                </div>
              </div> */}
            </div>
          </div>
        </div>
        <div className="mt-20"></div>
      </div>
    </MainContainer>
  );
};

export default Pool;
