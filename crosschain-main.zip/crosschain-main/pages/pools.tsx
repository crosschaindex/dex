import type { NextPage } from "next";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../app/hooks";
import { createPoolsApi } from "../clientApi";
import { PoolCard } from "../components/Card";
import { MainContainer } from "../components/Container";
import { getpools } from "../store/pool";

const Pools: NextPage = () => {
  const disptach = useAppDispatch();

  const pools = useAppSelector((state) => state.pool.pools);

  useEffect(() => {
    disptach(getpools());

    createPoolsApi()
  }, []);

  return (
    <MainContainer>
      <div className="flex flex-col w-full pt-28 items-center flex-1 overflow-x-hidden overflow-y-auto z-1 pool-content">
        <div className="grid auto-rows-auto gap-y-5 fixed right-4 top-28 w-full z-30 max-w-sm pool-div-1"></div>
        <div className="relative max-w-full h-0 m-0 hidden pool-div-2">
          <div className="flex flex-row h-full overflow-x-hidden overflow-y-auto"></div>
        </div>
        <div className="liquid-content gap-y-6 justify-center">
          <div className="stakepool-subcontent">
            <div className="liquid-provider">
              <span className="viper-bg"></span>
              <span className="viperoverlay-bg"></span>
              <div className="grid auto-rows-auto p-4 z-1">
                <div className="grid gap-y-3 auto-rows-auto">
                  <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                    <div className="m-0 min-w-0 font-semibold text-white">
                      CRC liquidity mining
                    </div>
                  </div>
                  <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                    <div className="m-0 font-medium text-white text-sm">
                      Deposit your Liquidity Provider tokens to receive CRC, the
                      CRC Protocol governance token.
                    </div>
                  </div>
                  <div className="m-0 min-w-0 w-full flex p-0 justify-between items-center">
                    <Link href="./archivedpools">
                      <a className="cursor-pointer text-blue font-medium">
                        <button className="archived-btn">
                          Archived Pools (40)
                        </button>
                      </a>
                    </Link>
                  </div>
                </div>
              </div>
              <span className="viper-bg"></span>
              <span className="viperoverlay-bg"></span>
            </div>
          </div>
          <div className="stakepool-subcontent gap-row-6">
            <div className="m-0 min-w-0 w-full flex p-0 justify-between items-baseline">
              <div className="mt-2 min-w-0 font-medium text-xl">Pools</div>
            </div>
            <input
              type="text"
              id="pools-search-input"
              placeholder="Search using name or symbol"
              className="pools-search-input"
            />
            <div className="pools-div">
              {pools &&
                pools.map((pool) => {
                  return <PoolCard key={pool._id} pool={pool} />;
                })}

          
              <div className="flex w-full justify-center mt-4 mb-2">
                <div>
                  <div className="px-5 text-blue cursor-pointer">←</div>
                </div>
                <div className="text-base m-0 min-w-0 font-normal">
                  Page 1 of 1
                </div>
                <div>
                  <div className="px-5 text-blue cursor-pointer">→</div>
                </div>
              </div>
            </div>
            <div className="m-0 min-w-0 font-medium text-sm text-center text-light">
              <span role="img" aria-label="wizard-icon" className="mr-2">
                ☁️
              </span>
              The base emission rate is currently <b>2</b> CRC per block.
              <br />
              <b>60</b>
              CRC will be minted every minute given the current emission
              schedule.
              <br />
              <br />
              <div className="m-0 min-w-0 text-xs text-center font-medium">
                * = The APY is calculated using a very simplified formula, it
                might not fully represent the exact APY
                <br />
                when factoring in the dynamic emission schedule and the
                locked/unlocked rewards vesting system.
              </div>
            </div>
          </div>
        </div>
        <div className="mt-20"></div>
      </div>
    </MainContainer>
  );
};

export default Pools;
