import { createSlice,createAsyncThunk } from '@reduxjs/toolkit'
import { getPoolsApi } from '../../clientApi';
import { IPool } from '../../types';
// import { PoolDocument } from '../../models/Pool';


export interface IPoolsState {
    pools: IPool[],   
    status: 'failed' | "success" | "idle" | "loading"
}

const initialState: IPoolsState = {
    pools: [],
    status: 'idle'
}

export const getpools = createAsyncThunk("user/getpools", async () => {
    let pools = await getPoolsApi();
    return { pools };
  }
);



export const poolSlice = createSlice({
    name: 'pool',
    initialState,
    reducers: {
        // setConnectModal: {
        //     reducer(state: IPoolsState, action: any) {
        //       state.pools = action.payload;
        //     },
        //     prepare(payload) {
        //       return {
        //         payload,
        //       };
        //     },
        //   },
        //   showConnect:(state) =>{
        //     state.connect = true;
        // },
    },
    extraReducers: (builder) => {
        // GET AUTHENTICATED USER
        builder.addCase(getpools.fulfilled, (state, action) => {
          state.pools = action.payload.pools;
          state.status = "success";
        });
        builder.addCase(getpools.rejected, (state, action) => {
          state.status = "failed";
        });
        builder.addCase(getpools.pending, (state, action) => {
          state.status = "loading";
        });
    
      
    
    
      },

})


export const selectPoolById = (state:any, poolId:string):IPool => {
    return state.pools.find((pool:IPool) => pool._id === poolId)  
}


// export const {  } = poolSlice.actions


export default poolSlice.reducer
