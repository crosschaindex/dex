import { createSlice } from '@reduxjs/toolkit'


export interface IModalState {
    connect: boolean,    
}

const initialState: IModalState = {
    connect: false
}


export const modalSlice = createSlice({
    name: 'modal',
    initialState,
    reducers: {
        setConnectModal: {
            reducer(state: IModalState, action: any) {
              state.connect = action.payload;
            },
            prepare(payload) {
              return {
                payload,
              };
            },
          },
        //   showConnect:(state) =>{
        //     state.connect = true;
        // },
    },

})

export const { setConnectModal } = modalSlice.actions


export default modalSlice.reducer
