import { isDev } from "../config"

export const APP_NAME = "CRCDEX"

export const LOCAL_STORAGE_KEY = "CRCDEX:auth"

export const JWT_SECRET_KEY = "a serect key have to veeb eere bst i know it hsjdbe a scnt but i know ka duja?"

export const USER_TOKEN = 'user-token'

export const defaultContentType = 'application/json'

export const APP_ORIGIN = isDev? 'http://localhost:3000' : 'http://localhost.com:3000'