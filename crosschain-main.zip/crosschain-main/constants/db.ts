

// export const MONGODB_URI = process.env.MONGODB_URI || ""

export const MONGODB_USERNAME = process.env.MONGODB_USERNAME
export const MONGODB_PASSWORD = process.env.MONGODB_PASSWORD
export const MONGODB_HOST = process.env.MONGODB_HOST
export const MONGODB_DATABASE = process.env.MONGODB_DATABASE

export const MONGODB_URI = `mongodb+srv://${MONGODB_USERNAME}:${MONGODB_PASSWORD}@${MONGODB_HOST}/${MONGODB_DATABASE}?retryWrites=true&w=majority`