import { isDev } from "../config"

/**
 * blokchain based constant variables
 */
const NETWORK_NAME = isDev ? 'rinkeby' : 'mainnet'
const INFURA_KEY = 'cb805f21370942ef9d05576080273ff9'

export const INFURA_HTTPS_RPC_ENDPOINT = `https://${NETWORK_NAME}.infura.io/v3/${INFURA_KEY}`

export const ETHERSCAN_LINK = 'https://etherscan.io'

export const CHAIN_ID = isDev ? '0x4' : '0x1' //0x1

export const MINTER_CONTRACT_ADDRESS = "0x9421727f1c74665833c5e0ddeb01db49d1e0f190"


export const USDT_ETH_CONTRACT_ADDRESS = "0xdAC17F958D2ee523a2206206994597C13D831ec7"
export const USDT_BNB_CONTRACT_ADDRESS = "0x55d398326f99059fF775485246999027B3197955"
export const USDT_TRON_CONTRACT_ADDRESS = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"