import { JWT_SECRET_KEY } from '../../constants'
import { IAuthJWTPayload, IUser } from '../../types'
import jwt from 'jsonwebtoken'

export const verifyToken = (token: string): Promise<IUser> => {
  return new Promise(async (resolve, reject) => {
    try {

      let decodedPayload = await jwt.verify(token, JWT_SECRET_KEY) as IAuthJWTPayload
      let payload = decodedPayload.payload

      const userPayload: IUser = {
        id: payload.id,
        username: payload.username,
        publicAddress: payload.publicAddress,
        email: "",
        bio: "",
        avatar: "",
        role: payload.role
      }
      resolve(userPayload)
      return
    } catch (err: any) {
      reject(new Error(err.message))
      return
    }
  })
}