import { defaultContentType } from "../constants";
import { IUser } from "../types";

export const checkUserApi = (publicAddress: string,referral:string): Promise<{
    publicAddress: string, nonce: number
  }> => {
    return new Promise(async (resolve, reject) => {
      try {

        const res = await fetch('/api/auth/check', {
          method: 'POST',
          headers: {
            Accept: defaultContentType,
            'Content-Type': defaultContentType,
          },
          body: JSON.stringify({
            publicAddress,
            referral
          }),
        })
        if (!res.ok) {
          throw new Error(res.statusText)
        }
        const { user } = await res.json()
        resolve({
          publicAddress: user.publicAddress, nonce: user.nonce
  
        })
  
      } catch (err) {
        reject(err)
      }
    })
  }
  
  export const authenticateUserApi = (signature: string, publicAddress: string): Promise<string> => {
    return new Promise(async (resolve, reject) => {
  
      try{
        const res = await fetch('/api/auth/connect', {
          method: 'POST',
          headers: {
            Accept: defaultContentType,
            'Content-Type': defaultContentType,
          },
          body: JSON.stringify({
            publicAddress,
            signature
          }),
        })
    
        // Throw error with status code in case Fetch API req failed
        if (!res.ok) {
          throw new Error(res.statusText)
        }
        const { token } = await res.json()
        resolve(token)
      }catch(err){
        reject(err)
      }
  
    })
  }
  
  export const getAuthenticatedUserApi = (): Promise<IUser> => {
    return new Promise(async (resolve, reject) => {
  
      try{
        const res = await fetch('/api/auth/check')
    
        // Throw error with status code in case Fetch API req failed
        if (!res.ok) {
          throw new Error(res.statusText)
        }
        const { user } = await res.json()
        resolve(user)
      }catch(err){
        reject(err)
      }
  
    })
  }
  
  
  export const logoutApi = (): Promise<boolean> => {
    return new Promise(async (resolve, reject) => {
        try{
            const res = await fetch('/api/auth/logout')
      
          if (!res.ok) {
            throw new Error(res.statusText)
          }
        resolve(true)
      }catch(err){
        reject(err)
      }
  
    })
  }
  
  
  