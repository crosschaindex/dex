import { defaultContentType } from "../constants"
import { PoolDocument } from "../models/Pool"

export const getPoolsApi = (): Promise<PoolDocument[]> => {
  return new Promise(async (resolve, reject) => {

    try {
      const res = await fetch('/api/pool')

      // Throw error with status code in case Fetch API req failed
      if (!res.ok) {
        throw new Error(res.statusText)
      }
      const { pools } = await res.json()
      resolve(pools)
    } catch (err) {
      reject(err)
    }

  })
}

export const getPoolByIdApi = (id: string): Promise<PoolDocument[]> => {
  return new Promise(async (resolve, reject) => {

    try {
      const res = await fetch('/api/pool/' + id)

      // Throw error with status code in case Fetch API req failed
      if (!res.ok) {
        throw new Error(res.statusText)
      }
      const { pool } = await res.json()
      resolve(pool)
    } catch (err) {
      reject(err)
    }

  })
}





export const createPoolsApi = (): Promise<PoolDocument> => {
  return new Promise(async (resolve, reject) => {

    try {
      const res = await fetch('/api/pool', {
        method: 'POST',
        headers: {
          Accept: defaultContentType,
          'Content-Type': defaultContentType,
        },
        body: JSON.stringify({
          primary: "CRC",
          secondary: "USDT",
          apy: "15",
          total: "1000000",
          pool_reward: "90",
          emission_rate: "3"
        }),
      })

      // Throw error with status code in case Fetch API req failed
      if (!res.ok) {
        throw new Error(res.statusText)
      }
      const { pools } = await res.json()
      resolve(pools)
    } catch (err) {
      reject(err)
    }

  })
}

export const createTransactionsApi = (data: any): Promise<any> => {
  return new Promise(async (resolve, reject) => {

    try {
      const res = await fetch('/api/transaction', {
        method: 'POST',
        headers: {
          Accept: defaultContentType,
          'Content-Type': defaultContentType,
        },
        body: JSON.stringify(data)
      })

      // Throw error with status code in case Fetch API req failed
      if (!res.ok) {
        throw new Error(res.statusText)
      }
      const { transaction } = await res.json()
      resolve(transaction)
    } catch (err) {
      reject(err)
    }

  })
}


