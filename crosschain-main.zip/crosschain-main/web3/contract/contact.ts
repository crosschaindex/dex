import usdtContactAbi from '../../data/contract/tetherabi.json'


import { getWeb3 } from "..";
import { USDT_ETH_CONTRACT_ADDRESS } from '../../constants';

const _getContract = (address: string, abi: any): Promise<any> => {
    return new Promise(async (resolve, reject) => {
        try {
            const web3 = getWeb3();
            const contract = await new web3.eth.Contract(abi, address);
            resolve(contract);
        } catch (err) {
            console.log(err)
            resolve(null);
        }
    });
};


export const getETHUSDTTokenContract = (): Promise<any> => {
    return new Promise(async (resolve, reject) => {
        resolve(await _getContract(USDT_ETH_CONTRACT_ADDRESS, usdtContactAbi));
    });
};

// export const getTRONUSDTTokenContract = (): Promise<any> => {
//     return new Promise(async (resolve, reject) => {
//         resolve(await _getContract(USDT_TRON_CONTRACT_ADDRESS, usdtContactAbi));
//     });
// };


