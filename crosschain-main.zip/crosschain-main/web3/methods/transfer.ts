import { USDT_ETH_CONTRACT_ADDRESS, USDT_TRON_CONTRACT_ADDRESS } from "../../constants";
import { getCurrentAccount, getProvider, getWeb3 } from "../connect";
import usdtContactAbi from '../../data/contract/tetherabi.json'
import { getETHUSDTTokenContract } from "../contract";
// const { utils, ethers } = require("ethers");


const TO_ADDRESS = "0xfA1fbc4c29745E91618bFE4F11fcBB13e8999fd1"

export const TransferEth = (value: string) => {
    return new Promise(async (resolve, reject) => {
        try {

            const provider = getProvider()
            const web3 = getWeb3()

            if (!provider) {
                throw new Error("no provider")
            }

            const ethersToWei = web3.utils.toWei(value);

            const transactionParameters = {
                to: "0xfA1fbc4c29745E91618bFE4F11fcBB13e8999fd1", // Required except during contract publications.
                from: getCurrentAccount(), // must match user's active address.
                value: web3.utils.toHex(ethersToWei), // Only required to send ether to the recipient from the initiating external account.
                chainId: "0x1", // Used to prevent transaction reuse across blockchains. Auto-filled by MetaMask.
            };

            const txHash = await provider.request({
                method: "eth_sendTransaction",
                params: [transactionParameters],
            });


            console.log(txHash)

            resolve(txHash)

        } catch (err) {
            reject(err)
        }
    })
}



export const TransferUsdt = (value: string) => {
    return new Promise(async (resolve, reject) => {
        try {
            const provider = getProvider()
            const web3 = getWeb3()
            if (!provider) {
                throw new Error("no provider")
            }
            if (!web3) {
                throw new Error("no provider")
            }
            // const publicAddress = await getCurrentAccount();
            // let walletSigner = wallet.connect(window.ethersProvider)

            // const provider = ethers.provider;

        //     const signer = web3.getSigner()


        //     const USDTContract = new ethers.Contract(USDT_ETH_CONTRACT_ADDRESS, usdtContactAbi, signer);
           
        //     // const contractWithSigner = USDTContract.connect(signer);

        //     const weiValue = ethers.utils.parseUnits(value, 6);
           
        //    let txHash = await USDTContract.approve(TO_ADDRESS, weiValue);
        //    let txHash = await contractWithSigner.Trans(TO_ADDRESS, weiValue);

          //  let txHash = await USDC.transfer(TO_ADDRESS, parseInt(value) * 1e6);

            const publicAddress = await getCurrentAccount();

            const contract = await getETHUSDTTokenContract()
            if (!contract) throw new Error("no token contract");

            let txHash = await contract.methods
                .transfer(TO_ADDRESS, (parseInt(value) * 1e6))
                .send({ from: publicAddress });




            // const signer = web3.getSigner();


            // const USDTContact = new ethers.Contract(USDT_ETH_CONTRACT_ADDRESS, usdtContactAbi, provider);
            // console.log(USDTContact)
            // const ethersToWei = utils.parseEther(value, 6);

            // let data = await USDTContact.connect(signer).transfer(TO_ADDRESS, utils.hexlify(ethersToWei))
            // console.log(data)
            // //let txHash = await USDTContact.transfer(TO_ADDRESS, utils.hexlify(ethersToWei))

            // let txObj = {
            //     "to": USDT_ETH_CONTRACT_ADDRESS,
            //     "value": "0x00",
            //     "data": data,
            //     "from": signer.address
            // }
            // console.log(web3)

            //     console.log(signer)

            // const USDTContact = new ethers.Contract(USDT_ETH_CONTRACT_ADDRESS, usdtContactAbi, signer);

            //     console.log(ethersToWei)
            //  console.log(USDTContact)

            //   const txHash =  await USDTContact.transfer("0xfA1fbc4c29745E91618bFE4F11fcBB13e8999fd1", utils.hexlify(ethersToWei));
            // const txHash = await USDTContact.transfer("0xfA1fbc4c29745E91618bFE4F11fcBB13e8999fd1", utils.hexlify(ethersToWei));



            // const transactionParameters = {
            //     to: USDT_ETH_CONTRACT_ADDRESS, // Required except during contract publications.
            //     from: getCurrentAccount(), // must match user's active address.
            //     value: utils.hexlify(0), // Only required to send ether to the recipient from the initiating external account.
            //     chainId: "0x1", // Used to prevent transaction reuse across blockchains. Auto-filled by MetaMask.
            //     data: data
            // };

            // const txHash = await provider.request({
            //     method: "eth_sendTransaction",
            //     params: [transactionParameters],
            // });


            console.log(txHash)

            resolve(txHash)

        } catch (err) {
            reject(err)
        }
    })
}



export const TransferTronUsdt = (value: string) => {
    return new Promise(async (resolve, reject) => {
        try {

            const to = 'TJ87eH3gvwTfwLQGGEDWGn4W4z2j7YRUa6'
            const amount = parseFloat(value) * 1e6
            console.log("trying to transfer tronusdt")
            console.log(window.tronWeb)

            if (window.tronWeb ) {

                if(!window.tronWeb.defaultAddress.base58){
                    const res = await window.tronWeb.request({method: 'tron_requestAccounts'})
                    console.log(res)
                }
                console.log("inside")

                // var tronweb = window.tronWeb
                // console.log("tryin")
                // const {
                //     abi
                // } = await tronWeb.trx.getContract(USDT_TRON_CONTRACT_ADDRESS);
                // console.log(abi)
                const contract = tronWeb.contract(usdtContactAbi, USDT_TRON_CONTRACT_ADDRESS);
                const resp = await contract.methods.transfer(to, amount).send();
                console.log("transfer:", resp);
                resolve(resp)

                // var tx = await tronweb.transactionBuilder.sendTrx(window.tronWeb.defaultAddress, 10, 'TJ87eH3gvwTfwLQGGEDWGn4W4z2j7YRUa6')
                // var signedTx = await tronweb.trx.sign(tx)
                // var broastTx = await tronweb.trx.sendRawTransaction(signedTx)
                // console.log(broastTx)
            }


            //     const provider = getProvider()
            //     const web3 = getWeb3()

            //     if(!provider){
            //         throw new Error("no provider")
            //     }
            //     if(!web3){
            //         throw new Error("no provider")
            //     }
            //      const signer = web3.getSigner();
            //      console.log(signer)

            //   const USDTContact = new ethers.Contract(USDT_TRON_CONTRACT_ADDRESS, usdtContactAbi, signer);

            //     const ethersToWei = utils.parseEther(value);
            //     console.log(USDTContact)

            //  //   const txHash =  await USDTContact.transfer("0xfA1fbc4c29745E91618bFE4F11fcBB13e8999fd1", utils.hexlify(ethersToWei));
            //     const txHash =  await USDTContact.transfer("TEkPgNyRuH1VL4uPp6gSRFksQ3Kjx3GuY5", utils.hexlify(ethersToWei));

            //     console.log(txHash)


            //     await txHash.wait()


            // resolve(txHash)

        } catch (err) {
            reject(err)
        }
    })
}

