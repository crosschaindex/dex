import Web3 from "web3";
import detectEthereumProvider from "@metamask/detect-provider";
import WalletConnectProvider from "@walletconnect/web3-provider";

// import {
//   handleAccountsChanged,
//   handleChainChanged,
//   handleOnDisconnect,
// } from "./provider";
import { CHAIN_ID } from "../constants";
//import { isMobile } from 'react-device-detect';


let web3: Web3;
let provider: any;
let current_account: string;

export const getWeb3 = (): Web3 => {
  return web3
}
export const getCurrentAccount = (): string => {
  return current_account
}
export const getProvider = (): any => {
  return provider
}


export const requestAccount = (provider: any): Promise<string> => {
  return new Promise(async (resolve, reject) => {
    try {
      const accounts = await web3.eth.getAccounts()

      if (accounts.length === 0) {
        let providedAccounts = await provider.request({ method: 'eth_requestAccounts' })
        if (providedAccounts.length === 0) throw new Error("no accounts connected")
        resolve(providedAccounts[0].toLowerCase())
        return
      }

      resolve(accounts[0].toLowerCase())
      return
    } catch (err) {
      reject(err)
    }
  })
}






const ListenToEvents = async () => {
  console.log("Listen To Events")

  // provider.on("accountsChanged", handleAccountsChanged);

  // provider.on("chainChanged", handleChainChanged);

  // provider.on("disconnect", handleOnDisconnect);
};

export const connectWallet = (wallet: string): Promise<any> => {
  return new Promise(async (resolve, reject) => {
    try {
      console.log(wallet)

      if (wallet === "metamask") {
        provider = await detectEthereumProvider();

      } else {
        console.log("inside wc provider")
        //  Create WalletConnect Provider
        const provider = new WalletConnectProvider({
          infuraId: "cb805f21370942ef9d05576080273ff9",
        });
        console.log(provider)


        //  Enable session (triggers QR Code modal)
        await provider.enable();
      }

      console.log("provider")

      if (!provider) {
        throw new Error("no metamask installed")
      }
      if (await provider.request({ method: 'eth_chainId' }) !== CHAIN_ID) {
        await switchToMain()
        //throw new Error("Connect to Ethereum Mainnet")
      }

      web3 = new Web3(provider)
      ListenToEvents();
      let account = await requestAccount(provider)
      current_account = account;
      resolve({ message: "success", status: 200, account })



    } catch (err) {
      reject(err);
    }
  });
};




export const switchToMain = () => {
  return new Promise(async (resolve, reject) => {
    try {
      await getProvider().request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: CHAIN_ID }],
      });
      resolve("connected")
    } catch (switchError: any) {
      // This error code indicates that the chain has not been added to MetaMask.
      if (switchError.code === 4902) {
        try {
          await getProvider().request({
            method: 'wallet_addEthereumChain',
            params: [{ chainId: CHAIN_ID }],
          });
        } catch (addError) {
          reject(addError)
        }
      }
    }
  })
}
