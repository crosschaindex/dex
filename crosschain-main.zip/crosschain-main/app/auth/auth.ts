import { authenticateUserApi, checkUserApi, logoutApi } from "../../clientApi";
import { APP_NAME } from "../../constants";
import { connectWallet, getProvider } from "../../web3";

// const fetcher = (url:string) =>
//   fetch(url)
//     .then((res) => res.json())
//     .then((json) => json.data)


export const LoginUser = (referral: string, wallet:string): Promise<string> => {
  return new Promise(async (resolve, reject) => {
    try {
      const response = await connectWallet(wallet);

      const { publicAddress, nonce } = await checkUserApi(response.account, referral);
      const signedMsg = await handleSignMessage(publicAddress, nonce);
      const token = await authenticateUserApi(signedMsg.signature, signedMsg.publicAddress)

      resolve(token)
    } catch (err) {
      reject(err)
    }
  });
};

export const LogoutUser = (): Promise<boolean> => {
  return new Promise(async (resolve, reject) => {
    try {
      await logoutApi()
      // await disconnectProvider()
      resolve(true)
    } catch (err) {
      reject(err)
    }

  })
}


const handleSignMessage = async (publicAddress: string, nonce: number): Promise<{
  publicAddress: string, signature: string
}> => {
  return new Promise(async (resolve, reject) => {
    try {
      const msg = `Please sign this message to connect to ${APP_NAME}(${nonce})`;
      const params = [msg, publicAddress];
      const method = "personal_sign";

      const provider = getProvider();

      if (!provider || provider === undefined) {
        throw new Error("connect to wallet");
      }
      const signature = await provider.request({
        method,
        params,
        publicAddress,
      });
      resolve({ publicAddress, signature });
    } catch (err) {
      console.log(err)
      reject({
        title: "Signature rejected",
        message: "You need to sign the message to be able to log in.",
      });
    }
  });
};

